# SPDX-License-Identifier: Apache-2.0
# Windows PowerShell 5.1 讀沒有 BOM 的 .ps1 會用系統碼頁（例如 Big5）解碼，中文會變亂碼而解析失敗。
# 所以每個 .ps1/.psm1/.psd1 都必須是 UTF-8 BOM + CRLF。
# 用法：python3 scripts/ps1_encoding.py --fix [資料夾...]   修正
#       python3 scripts/ps1_encoding.py --check [資料夾...] 只檢查，有問題就 exit 1
import os,sys
EXT=('.ps1','.psm1','.psd1');BOM=b'\xef\xbb\xbf';SKIP={'.git','node_modules'}
def files(roots):
    for r in roots:
        if os.path.isfile(r): yield r;continue
        for d,ds,fs in os.walk(r):
            ds[:]=[x for x in ds if x not in SKIP]
            for f in fs:
                if f.lower().endswith(EXT): yield os.path.join(d,f)
def normalize(b):
    t=b[3:] if b.startswith(BOM) else b
    t.decode('utf-8')  # 不是 UTF-8 就直接報錯
    t=t.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    return BOM+t
def main(a):
    mode=a[0] if a and a[0] in('--fix','--check') else '--check'
    roots=[x for x in a if not x.startswith('--')] or ['.']
    bad=[]
    for p in files(roots):
        b=open(p,'rb').read();n=normalize(b)
        if n!=b:
            if mode=='--fix': open(p,'wb').write(n)
            bad.append(p)
    for p in bad: print(('fixed ' if mode=='--fix' else 'FAIL（缺 UTF-8 BOM 或不是 CRLF）')+' '+p)
    if mode=='--check' and bad: sys.exit(1)
    if not bad: print('ps1 編碼全部正確（UTF-8 BOM + CRLF）')
if __name__=='__main__': main(sys.argv[1:])
