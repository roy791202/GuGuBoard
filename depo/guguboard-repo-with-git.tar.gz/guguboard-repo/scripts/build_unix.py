# SPDX-License-Identifier: Apache-2.0
# 建置 macOS／Linux 套件：GuGuBoard-macOS.tar.gz、GuGuBoard-Linux.tar.gz、guguboard_<ver>_all.deb
# 前提：先跑 build_payload.py（payload/core 是共用的安裝內容）
import os,shutil,subprocess,tarfile,hashlib,sys
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
VER=open('VERSION').read().strip();D='dist';ST='build/unix'
os.makedirs(D,exist_ok=True)
shutil.rmtree(ST,ignore_errors=True)
def stage(name):
    r=f'{ST}/{name}';shutil.copytree('build/payload/core',f'{r}/payload/core')
    c=f'{r}/payload/core'
    for f in ['guguboard','start-board.sh']: shutil.copy(f'installer/unix/{f}',f'{c}/{f}')
    shutil.copytree('installer/macos',f'{c}/macos')
    _pl=f'{c}/macos/Info.plist';open(_pl,'w').write(open(_pl).read().replace('0.1.0',VER));shutil.copytree('installer/linux',f'{c}/linux')
    shutil.copy('assets/gugu.icns',f'{c}/gugu.icns');shutil.copy('assets/mark-256.png',f'{c}/gugu-256.png')
    open(f'{c}/VERSION','w').write(VER+'\n')
    for f in ['install.sh','uninstall.sh']: shutil.copy(f'installer/unix/{f}',f'{r}/{f}')
    shutil.copy('installer/unix/README-unix.txt',f'{r}/README.txt')
    for root,_,fs in os.walk(r):
        for f in fs:
            p=os.path.join(root,f);m=0o755 if (f.endswith('.sh') or f in ('guguboard','GuGuBoard','pre-commit','commit-msg')) else 0o644;os.chmod(p,m)
    return r
def tgz(src,out,top):
    with tarfile.open(out,'w:gz') as t:
        t.add(src,arcname=top)
for os_ in ['macOS','Linux']:
    r=stage('GuGuBoard-'+os_);tgz(r,f'{D}/GuGuBoard-{os_}.tar.gz','GuGuBoard-'+os_)
# ---- .deb：/opt/guguboard（唯讀）＋ /usr/bin/guguboard ＋ 選單與圖示；設定放 ~/.config/guguboard ----
deb=f'{ST}/deb';c=f'{deb}/opt/guguboard'
shutil.copytree(f'{ST}/GuGuBoard-Linux/payload/core',c)
os.makedirs(f'{deb}/usr/bin');os.symlink('/opt/guguboard/guguboard',f'{deb}/usr/bin/guguboard')
os.makedirs(f'{deb}/usr/share/applications');open(f'{deb}/usr/share/applications/guguboard.desktop','w').write(open('installer/linux/guguboard.desktop').read().replace('@BIN@','/usr/bin/guguboard'))
for sz,src in [('256x256','assets/mark-256.png'),('128x128','assets/mark-128.png'),('48x48','assets/mark-48.png')]:
    os.makedirs(f'{deb}/usr/share/icons/hicolor/{sz}/apps');shutil.copy(src,f'{deb}/usr/share/icons/hicolor/{sz}/apps/guguboard.png')
os.makedirs(f'{deb}/usr/share/icons/hicolor/scalable/apps');shutil.copy('assets/gugu-mark.svg',f'{deb}/usr/share/icons/hicolor/scalable/apps/guguboard.svg')
os.makedirs(f'{deb}/DEBIAN')
size=sum(os.path.getsize(os.path.join(a,f)) for a,_,fs in os.walk(deb) for f in fs if not os.path.islink(os.path.join(a,f)))//1024
open(f'{deb}/DEBIAN/control','w').write(f'''Package: guguboard
Version: {VER}
Section: devel
Priority: optional
Architecture: all
Depends: git
Recommends: powershell | powershell-lts
Installed-Size: {size}
Maintainer: GuGuBoard Maintainers <roy791202@gmail.com>
Description: GuGuBoard - AI Dev 進度看板與 AI 開發流程技能
 本機進度看板（board.json）、Git 分頁、AI 提示詞與 Agent API、強制檢查（hooks／pre-commit／CI）。
 需要 PowerShell 7（pwsh）：sudo snap install powershell --classic，或 Microsoft 套件庫的 powershell。
''')
open(f'{deb}/DEBIAN/postinst','w').write('#!/bin/sh\nset -e\ncommand -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q /usr/share/applications || true\ncommand -v pwsh >/dev/null 2>&1 || echo "GuGuBoard：請安裝 PowerShell 7（sudo snap install powershell --classic）"\nexit 0\n')
os.chmod(f'{deb}/DEBIAN/postinst',0o755)
for root,dirs,fs in os.walk(deb):
    for d_ in dirs: os.chmod(os.path.join(root,d_),0o755)
if shutil.which('dpkg-deb'): subprocess.check_call(['dpkg-deb','--root-owner-group','--build',deb,f'{D}/guguboard_{VER}_all.deb'])
if '--no-deb' in sys.argv or not shutil.which('dpkg-deb'): pass
for f in [f'GuGuBoard-macOS.tar.gz','GuGuBoard-Linux.tar.gz',f'guguboard_{VER}_all.deb']:
    if os.path.exists(f'{D}/{f}'): print(f,hashlib.sha256(open(f'{D}/{f}','rb').read()).hexdigest())
