# SPDX-License-Identifier: Apache-2.0
# Windows 套件：dist/GuGuBoard-Setup.exe（需要 makensis）與 dist/GuGuBoard-PowerShell.zip
import os,shutil,subprocess,zipfile,sys
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
os.makedirs('dist',exist_ok=True)
subprocess.check_call([sys.executable,'installer/windows/gen_nsi.py'])
mk=shutil.which('makensis')
if mk: subprocess.check_call([mk,'-V2','-NOCD','build/installer.nsi'])
else: print('略過 exe：找不到 makensis（Windows：choco install nsis；Linux：apt install nsis）')
with zipfile.ZipFile('dist/GuGuBoard-PowerShell.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in ['install.ps1','uninstall.ps1','README.txt']: z.write(f'installer/windows/{f}',f)
    for f in ['LICENSE','NOTICE']: z.write(f,f)
    for r,_,fs in os.walk('build/payload'):
        for f in fs: p=os.path.join(r,f); z.write(p,os.path.relpath(p,'build'))
print('dist/GuGuBoard-PowerShell.zip')
