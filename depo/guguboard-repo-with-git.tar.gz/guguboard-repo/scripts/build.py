# SPDX-License-Identifier: Apache-2.0
# 一次建置全部：python3 scripts/build.py [--no-windows] [--no-unix] [--pkg]
import os,sys,subprocess,hashlib,glob
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
py=sys.executable;a=sys.argv[1:]
subprocess.check_call([py,'scripts/build_payload.py'])
if '--no-windows' not in a: subprocess.check_call([py,'scripts/build_windows.py'])
if '--no-unix' not in a: subprocess.check_call([py,'scripts/build_unix.py'])
if '--pkg' in a: subprocess.check_call(['sh','scripts/build_pkg.sh'])
import shutil; shutil.copy('installer/unix/get-guguboard.sh','dist/get-guguboard.sh'); shutil.copy('docs/guide.html','dist/guide.html')
with open('dist/SHA256SUMS.txt','w',newline='\n') as f:
    for p in sorted(glob.glob('dist/*')):
        if p.endswith('SHA256SUMS.txt'): continue
        f.write(hashlib.sha256(open(p,'rb').read()).hexdigest()+'  '+os.path.basename(p)+'\n')
print(open('dist/SHA256SUMS.txt').read())
