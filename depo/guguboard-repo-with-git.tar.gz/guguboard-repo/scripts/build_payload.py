# SPDX-License-Identifier: Apache-2.0
import os,re,shutil
import os as _o; _o.chdir(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),'..'))
SRC='skills'
IDS=['ai-dev-pipeline','ai-dev-preproduction','ai-dev-implementation','ai-dev-pr-acceptance','ai-dev-production-readiness']
P='build/payload'; shutil.rmtree(P,ignore_errors=True)
def w(path,txt):
    os.makedirs(os.path.dirname(path),exist_ok=True); open(path,'w',encoding='utf-8',newline='\n').write(txt)
sk={}
for i in IDS:
    t=open(f'{SRC}/{i}/SKILL.md',encoding='utf-8').read()
    fm,body=re.match(r'^---\n(.*?)\n---\n(.*)$',t,re.S).groups()
    d=re.search(r'description:\s*(?:>-\n((?:[ \t]+.*\n?)+)|(.*))',fm)
    desc=''.join(x.strip() for x in (d.group(1) or d.group(2)).splitlines()) if d.group(1) else d.group(2).strip()
    sk[i]=(t,body,desc.replace('"',"'"))
hdr='# AI 開發流程規則（GuGuBoard）\n\n> 由 GuGuBoard 安裝程式產生。看板在 `.ai-pm/board.json`；用 GuGuBoard「🤖 AI 提示詞」取得工作提示詞，領單流程與燈號規則 L1–L7 見 ai-dev-pipeline。驗證角色絕對不可以是開發程式角色。\n\n## 技能索引\n'+''.join(f'- **{i}**：{sk[i][2]}\n' for i in IDS)
full=hdr+''.join(f'\n\n---\n\n<!-- skill: {i} -->\n{sk[i][1]}' for i in IDS)
for i in IDS:
    t,b,d=sk[i]
    w(f'{P}/skills/skills/{i}/SKILL.md',t)
    w(f'{P}/cursor/.cursor/skills/{i}/SKILL.md',t)
    w(f'{P}/cursor/.cursor/rules/{i}.mdc',f'---\ndescription: "{d}"\nglobs:\nalwaysApply: false\n---\n{b}')
    w(f'{P}/claude/.claude/skills/{i}/SKILL.md',t)
    w(f'{P}/windsurf/.windsurf/rules/{i}.md',f'---\ntrigger: model_decision\ndescription: "{d}"\n---\n{b}')
    w(f'{P}/cline/.clinerules/{i}.md',b)
w(f'{P}/codex/AGENTS.md',full)
w(f'{P}/gemini/GEMINI.md',full)
w(f'{P}/copilot/.github/copilot-instructions.md',full)
w(f'{P}/claude/CLAUDE.md',hdr+'\n技能完整內容在 `.claude/skills/<id>/SKILL.md`，Claude Code 會依描述自動載入；也可輸入 `/ai-dev-preproduction` 等名稱呼叫。\n')
w(f'{P}/guide/docs/ai-dev-skills/guide.html',open('docs/guide.html',encoding='utf-8').read())

# ---- AI Hooks（Cursor + Claude Code）----
import shutil as _s
os.makedirs(f'{P}/hooks/.ai-hooks',exist_ok=True)
_s.copy('src/hooks/ai-hook.ps1',f'{P}/hooks/.ai-hooks/ai-hook.ps1')
_s.copy('src/hooks/ai-hook.sh',f'{P}/hooks/.ai-hooks/ai-hook.sh')
_s.copy('src/hooks/config.json',f'{P}/hooks/.ai-hooks/config.json')
w(f'{P}/hooks/.ai-hooks/.gitignore','logs/\n')
os.makedirs(f'{P}/hooks/.cursor',exist_ok=True); os.makedirs(f'{P}/hooks/.claude',exist_ok=True)
_s.copy('src/hooks/hooks.json',f'{P}/hooks/.cursor/hooks.json')
_s.copy('src/hooks/settings.json',f'{P}/hooks/.claude/settings.json')

# ---- 看板範本 ----
_s.copy('src/hooks/BOARD-TEMPLATE.md',f'{P}/guide/docs/ai-dev-skills/BOARD-TEMPLATE.md')

# ---- HTML 進度看板（監聽 board.json）----
# 看板執行層放在安裝根目錄（最外層）
for f in ['board.html','serve-board.ps1','serve-ext.ps1','start-tunnel.ps1','apply-project.ps1','board.example.json','board.schema.json','start-board.ps1','start-board.cmd','serve-mcp.ps1','mcp-stdio.ps1','guguboard-mcp.ps1','guguboard.cmd']:
    _s.copy(f'src/board/{f}',f'{P}/guide/{f}')

# ---- BDD 範本 ----
os.makedirs(f'{P}/guide/docs/ai-dev-skills/templates',exist_ok=True)
_s.copy('templates/story.feature.template',f'{P}/guide/docs/ai-dev-skills/templates/story.feature.template')

# ---- 強制機制：AI Hooks 驗證器、Git Hooks、CI Guard ----
_s.copy('src/hooks/validate-board.ps1',f'{P}/hooks/.ai-hooks/validate-board.ps1')
for d in ['githooks/.githooks','githooks/scripts','ciguard/.github/ai-dev-guard','ciguard/.github/workflows','guide/docs/ai-dev-skills']: os.makedirs(f'{P}/{d}',exist_ok=True)
for f in ['check.ps1','pre-commit','commit-msg']: _s.copy(f'enforce/{f}',f'{P}/githooks/.githooks/{f}')
_s.copy('src/hooks/validate-board.ps1',f'{P}/githooks/.githooks/validate-board.ps1')
_s.copy('enforce/install-git-hooks.ps1',f'{P}/githooks/scripts/install-git-hooks.ps1')
_s.copy('enforce/guard.ps1',f'{P}/ciguard/.github/ai-dev-guard/guard.ps1')
_s.copy('src/hooks/validate-board.ps1',f'{P}/ciguard/.github/ai-dev-guard/validate-board.ps1')
_s.copy('enforce/ai-dev-guard.yml',f'{P}/ciguard/.github/workflows/ai-dev-guard.yml')
_s.copy('enforce/BRANCH-PROTECTION.md',f'{P}/guide/docs/ai-dev-skills/BRANCH-PROTECTION.md')
_s.copy('src/hooks/validate-board.ps1',f'{P}/guide/validate-board.ps1')
# 圖示與標誌
for _f in ['gugu.ico','gugu-logo.svg','gugu-mark.svg','gugu-logo.png']: _s.copy('assets/'+_f,f'{P}/guide/'+_f)
# 指南引用的截圖
import re as _re
for _img in sorted(set(_re.findall(r'src="(board-[a-z0-9-]+\.png)"',open('docs/guide.html',encoding='utf-8').read()))):
    if os.path.exists('docs/'+_img): _s.copy('docs/'+_img,f'{P}/guide/docs/ai-dev-skills/'+_img)

# ---- GuGuBoard 獨立工具配置：payload/core = 安裝根目錄 ----
# 看板執行層、指南、母版 skills 放在安裝根；專案層檔案放在 project-templates\<tool>\，由 apply-project.ps1 套用到各專案 repo
os.rename(f'{P}/guide',f'{P}/core')
_s.move(f'{P}/skills/skills',f'{P}/core/skills'); _s.rmtree(f'{P}/skills')
for t in ['cursor','codex','claude','copilot','windsurf','gemini','cline','hooks','githooks','ciguard']:
    _s.move(f'{P}/{t}',f'{P}/core/project-templates/{t}')
# 授權檔隨附於安裝資料夾（Apache-2.0）
import shutil as _sh
for _f in ['LICENSE','NOTICE']: _sh.copy(_f,f'build/payload/core/{_f}')
# 所有 .ps1 一律 UTF-8 BOM + CRLF（Windows PowerShell 5.1 沒 BOM 會用 Big5 等碼頁解碼而解析失敗）
import subprocess as _sp,sys as _sy
_sp.check_call([_sy.executable,'scripts/ps1_encoding.py','--fix','build/payload'])
_sp.check_call([_sy.executable,'scripts/ps1_encoding.py','--check','build/payload'])
