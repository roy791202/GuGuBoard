#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# macOS .pkg（只能在 macOS 上執行，需要 pkgbuild）：安裝到 /Applications/GuGuBoard 與 /Applications/GuGuBoard.app
set -eu
cd "$(dirname "$0")/.."
command -v pkgbuild >/dev/null 2>&1 || { echo "找不到 pkgbuild（只有 macOS 有）"; exit 1; }
VER=$(cat VERSION); ST=build/pkg; rm -rf "$ST"; mkdir -p "$ST/root/Applications" "$ST/scripts"
tar -xzf dist/GuGuBoard-macOS.tar.gz -C "$ST"
cp -R "$ST/GuGuBoard-macOS/payload/core" "$ST/root/Applications/GuGuBoard"
cp "$ST/GuGuBoard-macOS/install.sh" "$ST/GuGuBoard-macOS/uninstall.sh" "$ST/root/Applications/GuGuBoard/"
APP="$ST/root/Applications/GuGuBoard.app/Contents"; mkdir -p "$APP/MacOS" "$APP/Resources"
cp "$ST/root/Applications/GuGuBoard/macos/Info.plist" "$APP/Info.plist"
sed 's#@PREFIX@#/Applications/GuGuBoard#g' "$ST/root/Applications/GuGuBoard/macos/GuGuBoard" > "$APP/MacOS/GuGuBoard"; chmod 755 "$APP/MacOS/GuGuBoard"
cp "$ST/root/Applications/GuGuBoard/gugu.icns" "$APP/Resources/gugu.icns"
cat > "$ST/scripts/postinstall" <<'P'
#!/bin/sh
command -v pwsh >/dev/null 2>&1 || [ -x /usr/local/bin/pwsh ] || [ -x /opt/homebrew/bin/pwsh ] || echo "GuGuBoard: install PowerShell 7 (brew install --cask powershell)"
exit 0
P
chmod 755 "$ST/scripts/postinstall"
SIGN=""; [ -n "${PKG_SIGN_IDENTITY:-}" ] && SIGN="--sign $PKG_SIGN_IDENTITY"
# shellcheck disable=SC2086
pkgbuild --root "$ST/root" --scripts "$ST/scripts" --identifier io.github.roy791202.guguboard.pkg --version "$VER" --install-location / $SIGN "dist/GuGuBoard-$VER-macOS.pkg"
echo "dist/GuGuBoard-$VER-macOS.pkg"
