GuGuBoard（macOS／Linux）

需要：PowerShell 7（pwsh）與 git。
  macOS：brew install --cask powershell；git：xcode-select --install
  Ubuntu／Debian：sudo snap install powershell --classic（或 Microsoft 套件庫：sudo apt install powershell）；sudo apt install git

安裝（可重複執行＝原地升級，.ai-board 設定保留，你改過的檔案先備份成 .bak）：
  sh install.sh                 # macOS → ~/Applications/GuGuBoard ＋ ~/Applications/GuGuBoard.app
                                # Linux → ~/.local/share/gugu-board ＋ ~/.local/bin/guguboard ＋ 應用程式選單
  sh install.sh --system        # macOS：/Applications（需要權限，請自行 sudo）
  sh install.sh --prefix <目錄> --no-launcher --no-open

使用：
  guguboard start               # 背景啟動並開瀏覽器 http://localhost:8765/
  guguboard run | stop | status | open
  guguboard apply <repo 資料夾> [-Tools Cursor,Claude,Hooks,GitHooks,CIGuard] [-Plan]

移除：sh uninstall.sh [--purge]   （--purge 才會刪 .ai-board）

一行安裝（把 tar.gz 與 get-guguboard.sh 放到你自己的網址）：
  curl -fsSL https://<你的主機>/get-guguboard.sh | GUGUBOARD_BASE=https://<你的主機> sh
