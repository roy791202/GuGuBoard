#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# 移除 GuGuBoard（macOS／Linux）：只刪除安裝清單內、沒被修改過的檔案與啟動器；.ai-board（帳號與設定）保留，除非加 --purge。
# 用法：sh uninstall.sh [--prefix 目錄] [--purge]
set -eu
OS=$(uname -s); PREFIX=""; PURGE=0
while [ $# -gt 0 ]; do case $1 in --prefix) PREFIX=$2; shift ;; --prefix=*) PREFIX=${1#*=} ;; --purge) PURGE=1 ;; *) echo "不認得的參數：$1" >&2; exit 2 ;; esac; shift; done
if [ -z "$PREFIX" ]; then
  if [ "$OS" = Darwin ]; then PREFIX="$HOME/Applications/GuGuBoard"; [ -f "$PREFIX/.guguboard-manifest.txt" ] || PREFIX=/Applications/GuGuBoard
  else PREFIX="${XDG_DATA_HOME:-$HOME/.local/share}/gugu-board"; fi
fi
MAN="$PREFIX/.guguboard-manifest.txt"
[ -f "$MAN" ] || { echo "找不到 $MAN，$PREFIX 看起來不是 GuGuBoard 安裝資料夾" >&2; exit 1; }
[ -x "$PREFIX/guguboard" ] && "$PREFIX/guguboard" stop >/dev/null 2>&1 || true
if command -v sha256sum >/dev/null 2>&1; then SHA="sha256sum"; else SHA="shasum -a 256"; fi
kept=0
while IFS='|' read -r k a h; do
  case $k in
    F) d="$PREFIX/$a"; [ -f "$d" ] || continue; if [ "$($SHA "$d" | cut -d' ' -f1)" = "$h" ]; then rm -f "$d"; else echo "  保留你修改過的 $a"; kept=1; fi ;;
    L) rm -f "$a" ;;
    M) case $a in */GuGuBoard.app) rm -rf "$a" ;; esac ;;
  esac
done <"$MAN"
rm -f "$MAN"
if [ $PURGE = 1 ]; then rm -rf "$PREFIX/.ai-board"; fi
find "$PREFIX" -depth -type d -empty -exec rmdir {} \; 2>/dev/null || true
if [ -d "$PREFIX" ]; then echo "已移除 GuGuBoard；$PREFIX 內保留：$(ls -A "$PREFIX" | tr '\n' ' ')"; else echo "已移除 GuGuBoard（$PREFIX）"; fi
