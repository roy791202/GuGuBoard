#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# 前景啟動 GuGuBoard（等同 guguboard run）
exec "$(dirname "$0")/guguboard" run "$@"
