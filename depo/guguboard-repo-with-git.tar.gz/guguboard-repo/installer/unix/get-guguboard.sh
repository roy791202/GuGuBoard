#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# GuGuBoard 一行安裝（macOS／Linux）：下載 tar.gz、驗證 SHA-256（有提供時）、解壓並執行 install.sh。不會使用 sudo。
# 用法：curl -fsSL https://github.com/roy791202/GuGuBoard/releases/latest/download/get-guguboard.sh | sh
# 自架：GUGUBOARD_BASE=https://<你的主機> sh get-guguboard.sh
#       （可加 GUGUBOARD_SHA256=<雜湊> 驗證；install.sh 的參數放在 sh -s -- 後面，例如 | sh -s -- --no-open）
set -eu
BASE=${GUGUBOARD_BASE:-https://github.com/roy791202/GuGuBoard/releases/latest/download}
case $(uname -s) in Darwin) PKG=GuGuBoard-macOS ;; Linux) PKG=GuGuBoard-Linux ;; *) echo "不支援的系統：$(uname -s)" >&2; exit 1 ;; esac
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
echo "下載 $BASE/$PKG.tar.gz"
curl -fsSL "$BASE/$PKG.tar.gz" -o "$TMP/p.tgz"
if [ -n "${GUGUBOARD_SHA256:-}" ]; then
  if command -v sha256sum >/dev/null 2>&1; then H=$(sha256sum "$TMP/p.tgz" | cut -d' ' -f1); else H=$(shasum -a 256 "$TMP/p.tgz" | cut -d' ' -f1); fi
  [ "$H" = "$GUGUBOARD_SHA256" ] || { echo "SHA-256 不符，停止安裝" >&2; exit 1; }
fi
tar -xzf "$TMP/p.tgz" -C "$TMP"
sh "$TMP/$PKG/install.sh" "$@"
