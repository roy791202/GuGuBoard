#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# GuGuBoard 安裝程式（macOS／Linux，POSIX sh）。可重複執行＝原地升級；不會自動使用 sudo。
# 用法：sh install.sh [--prefix 目錄] [--system] [--no-launcher] [--no-open] [--force]
#   預設位置：macOS ~/Applications/GuGuBoard（--system 且有權限時 /Applications/GuGuBoard）；Linux ~/.local/share/gugu-board
#   .ai-board（帳號、專案與密鑰）在升級時保留；你改過的檔案會先備份成 .bak
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SRC="$HERE/payload/core"
[ -d "$SRC" ] || { echo "找不到 $SRC（請在解壓縮後的資料夾執行）" >&2; exit 1; }
OS=$(uname -s); PREFIX=""; SYSTEM=0; LAUNCHER=1; OPEN=1; FORCE=0
while [ $# -gt 0 ]; do case $1 in
  --prefix) PREFIX=$2; shift ;; --prefix=*) PREFIX=${1#*=} ;;
  --system) SYSTEM=1 ;; --no-launcher) LAUNCHER=0 ;; --no-open) OPEN=0 ;; --force) FORCE=1 ;;
  -h|--help) sed -n '2,6p' "$0"; exit 0 ;; *) echo "不認得的參數：$1" >&2; exit 2 ;; esac; shift; done
if [ -z "$PREFIX" ]; then
  if [ "$OS" = Darwin ]; then
    if [ $SYSTEM = 1 ]; then [ -w /Applications ] || { echo "/Applications 沒有寫入權限。請改用預設（~/Applications），或自行用 sudo 執行：sudo sh install.sh --system" >&2; exit 1; }; PREFIX=/Applications/GuGuBoard
    else PREFIX="$HOME/Applications/GuGuBoard"; fi
  else PREFIX="${XDG_DATA_HOME:-$HOME/.local/share}/gugu-board"; fi
fi
# ---- 相依檢查（只提示，不自動安裝）----
if ! command -v pwsh >/dev/null 2>&1; then
  echo "⚠ 找不到 PowerShell 7（pwsh），GuGuBoard 需要它才能執行。安裝方式："
  if [ "$OS" = Darwin ]; then echo "    brew install --cask powershell"
  else echo "    Ubuntu／Debian：sudo snap install powershell --classic"; echo "    或加入 Microsoft 套件庫後：sudo apt install powershell（https://aka.ms/install-powershell）"
       echo "    Fedora／RHEL：sudo dnf install powershell（同上加入套件庫）"; fi
  [ $FORCE = 1 ] || { echo "裝好 pwsh 後再執行一次；或加 --force 先安裝檔案。" >&2; exit 1; }
fi
command -v git >/dev/null 2>&1 || { echo "⚠ 找不到 git（版本歷史、Git 分頁與套用到專案需要）。macOS：xcode-select --install 或 brew install git；Linux：sudo apt install git"; }
if command -v sha256sum >/dev/null 2>&1; then SHA="sha256sum"; else SHA="shasum -a 256"; fi
sha() { $SHA "$1" | cut -d' ' -f1; }
# ---- 複製（原地升級：依上次的安裝清單判斷你是否改過檔案）----
mkdir -p "$PREFIX"; MAN="$PREFIX/.guguboard-manifest.txt"; NEW="$MAN.new"; : >"$NEW"
n=0; u=0; s=0; b=0
cd "$SRC"
find . -type f | sed 's|^\./||' | sort | while IFS= read -r f; do
  d="$PREFIX/$f"; mkdir -p "$(dirname "$d")"; hs=$(sha "$f")
  if [ -f "$d" ]; then
    hd=$(sha "$d")
    if [ "$hd" = "$hs" ]; then :
    else
      prev=$(grep -F "|$f|" "$MAN" 2>/dev/null | head -n1 | cut -d'|' -f3 || true)
      if [ -n "$prev" ] && [ "$prev" = "$hd" ]; then cp "$f" "$d"
      else bk="$d.bak"; [ -e "$bk" ] && bk="$d.$(date +%Y%m%d%H%M%S).bak"; cp "$d" "$bk"; cp "$f" "$d"; echo "  已備份你修改過的 $f → $(basename "$bk")"; fi
    fi
  else cp "$f" "$d"; fi
  echo "F|$f|$hs" >>"$NEW"
done
cd "$HERE"
# 舊版有、新版沒有、而且沒被修改的檔案才刪除
if [ -f "$MAN" ]; then
  grep '^F|' "$MAN" | while IFS='|' read -r _ f h; do
    grep -qF "|$f|" "$NEW" && continue; d="$PREFIX/$f"
    [ -f "$d" ] && [ "$(sha "$d")" = "$h" ] && rm -f "$d"
  done
fi
mv "$NEW" "$MAN"
chmod +x "$PREFIX/guguboard" "$PREFIX/start-board.sh" 2>/dev/null || true
mkdir -p "$PREFIX/.ai-board" && chmod 700 "$PREFIX/.ai-board"
# ---- 啟動器 ----
if [ $LAUNCHER = 1 ]; then
  if [ "$OS" = Darwin ]; then
    APPDIR=$(dirname "$PREFIX"); APP="$APPDIR/GuGuBoard.app"
    mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
    sed "s|@PREFIX@|$PREFIX|g" "$PREFIX/macos/GuGuBoard" >"$APP/Contents/MacOS/GuGuBoard"; chmod +x "$APP/Contents/MacOS/GuGuBoard"
    cp "$PREFIX/macos/Info.plist" "$APP/Contents/Info.plist"; cp "$PREFIX/gugu.icns" "$APP/Contents/Resources/gugu.icns"
    echo "M|$APP" >>"$MAN"; echo "已建立 $APP（雙擊即啟動並開啟瀏覽器）"
    mkdir -p "$HOME/.local/bin" 2>/dev/null && ln -sf "$PREFIX/guguboard" "$HOME/.local/bin/guguboard" && echo "L|$HOME/.local/bin/guguboard" >>"$MAN"
  else
    BIN="$HOME/.local/bin"; APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"; ICO="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor"
    mkdir -p "$BIN" "$APPS" "$ICO/256x256/apps" "$ICO/scalable/apps"
    ln -sf "$PREFIX/guguboard" "$BIN/guguboard"
    cp "$PREFIX/gugu-256.png" "$ICO/256x256/apps/guguboard.png"; cp "$PREFIX/gugu-mark.svg" "$ICO/scalable/apps/guguboard.svg"
    sed "s|@BIN@|$BIN/guguboard|g" "$PREFIX/linux/guguboard.desktop" >"$APPS/guguboard.desktop"
    command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1 || true
    printf 'L|%s\nL|%s\nL|%s\nL|%s\n' "$BIN/guguboard" "$APPS/guguboard.desktop" "$ICO/256x256/apps/guguboard.png" "$ICO/scalable/apps/guguboard.svg" >>"$MAN"
    echo "已建立 $BIN/guguboard 與應用程式選單項目「GuGuBoard」"
    case ":$PATH:" in *":$BIN:"*) ;; *) echo "提示：把 $BIN 加到 PATH（例如在 ~/.profile 加 export PATH=\"\$HOME/.local/bin:\$PATH\"）";; esac
  fi
fi
echo "已安裝 GuGuBoard 到 $PREFIX"
echo "啟動：guguboard start（或 $PREFIX/guguboard start）；套用到專案：guguboard apply <repo 資料夾>"
if [ $OPEN = 1 ] && command -v pwsh >/dev/null 2>&1; then "$PREFIX/guguboard" start || true; fi
