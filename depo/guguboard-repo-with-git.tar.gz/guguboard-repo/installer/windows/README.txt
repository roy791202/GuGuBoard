GuGuBoard 安裝包（PowerShell 版）— AI Dev 進度看板 + AI 開發流程技能（獨立工具，不需裝在專案內）
安裝：powershell -ExecutionPolicy Bypass -File .\install.ps1 [-InstallPath D:\AI_PM] [-Migrate ask|yes|no]
套用到專案 repo：powershell -ExecutionPolicy Bypass -File D:\AI_PM\apply-project.ps1 -RepoPath D:\code\myapp [-Tools Cursor,Claude,Hooks,GitHooks,CIGuard] [-Plan] [-Commit]
  （也可以在看板網頁「新增專案」或「👥 帳號 → 套用到專案」操作；-Remove 可移除套用並還原 .bak）
移除：powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 [-InstallPath D:\AI_PM]（.ai-board 設定保留）
預設路徑 D:\AI_PM。偵測到舊版 D:\AI_INSTRUCTIONS 時可把 .ai-board 設定複製過來（舊的不刪）。
詳見 payload\core\docs\ai-dev-skills\guide.html
