﻿# SPDX-License-Identifier: Apache-2.0
<#
.SYNOPSIS  安裝 GuGuBoard（AI Dev 進度看板 + AI 開發流程技能）成為獨立工具。可重複執行。
.DESCRIPTION
  安裝到 -InstallPath（預設 D:\AI_PM）：看板執行層、使用指南、母版 skills、project-templates\（各 AI 工具與強制檢查的專案層檔案）、apply-project.ps1。
  GuGuBoard 不需要裝在專案裡；要讓某個專案 repo 使用 AI 工具規則與 hooks，請在看板「新增專案」或「👥 帳號 → 套用到專案」操作，
  或執行 apply-project.ps1 -RepoPath <repo>（也可以在這裡加 -ApplyTo <repo>）。
  偵測到舊版安裝（D:\AI_INSTRUCTIONS 或舊的移除登錄）時，可把舊 .ai-board（帳號、專案設定）複製過來；舊資料夾不會被刪除。
.EXAMPLE   .\install.ps1
.EXAMPLE   .\install.ps1 -InstallPath D:\AI_PM -Migrate yes -ApplyTo D:\code\myapp -Tools Cursor,Claude,Hooks,GitHooks
#>
[CmdletBinding()]
param(
  [Alias('ProjectPath')][string]$InstallPath = 'D:\AI_PM',
  [ValidateSet('ask','yes','no')][string]$Migrate = 'ask',
  [string]$MigrateFrom = '',
  [string]$ApplyTo = '',
  [ValidateSet('Cursor','Codex','Claude','Copilot','Windsurf','Gemini','Cline','Hooks','GitHooks','CIGuard')]
  [string[]]$Tools = @('Cursor','Codex','Claude','Copilot','Windsurf','Gemini','Cline','Hooks','GitHooks','CIGuard'),
  [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
function ConvertTo-OsPath([string]$r) { $r -replace '\\', [IO.Path]::DirectorySeparatorChar }
$payload = Join-Path (Join-Path $PSScriptRoot 'payload') 'core'
if (-not (Test-Path $payload)) { throw "找不到 payload 資料夾：$payload" }
New-Item -ItemType Directory -Force -Path $InstallPath | Out-Null
$target = (Resolve-Path $InstallPath).Path.TrimEnd('\', '/')
$manifestPath = Join-Path $target '.ai-dev-skills-manifest.txt'
$old = @(); if (Test-Path $manifestPath) { $old = @(Get-Content -LiteralPath $manifestPath -Encoding UTF8) }
$installedBefore = @{}; foreach ($l in $old) { if ($l -like 'F|*') { $installedBefore[$l.Substring(2)] = $true } }
$lines = [System.Collections.Generic.List[string]]::new()
foreach ($l in $old) { if ($l -like 'B|*' -and -not $lines.Contains($l)) { $lines.Add($l) } }
$stats = @{ new = 0; updated = 0; same = 0; backup = 0 }

# ---------- 舊版設定遷移（複製，不刪除舊的）----------
function Find-OldInstall {
  $c = @(); if ($MigrateFrom) { $c += $MigrateFrom }
  foreach ($k in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIDevSkills', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AIDevSkills') {
    try { $v = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).InstallLocation; if ($v) { $c += [string]$v } } catch {}
  }
  $c += 'D:\AI_INSTRUCTIONS'
  foreach ($d in $c) {
    if (-not $d) { continue }
    try { $full = [IO.Path]::GetFullPath($d).TrimEnd('\', '/') } catch { continue }
    if ($full -eq $target) { continue }
    foreach ($cfg in (Join-Path $full '.ai-board'), (Join-Path $full 'docs\ai-dev-skills\board\.ai-board')) { if (Test-Path -LiteralPath (Join-Path $cfg 'users.json')) { return $cfg } }
  }
  $null
}
$newCfg = Join-Path $target '.ai-board'
if ($Migrate -ne 'no' -and -not (Test-Path -LiteralPath (Join-Path $newCfg 'users.json'))) {
  $oc = Find-OldInstall
  if ($oc) {
    $go = $Migrate -eq 'yes'
    if ($Migrate -eq 'ask') { $a = Read-Host "找到舊版設定 $oc（帳號、專案登記）。要複製到 $newCfg 嗎？舊資料夾不會被刪除 [Y/n]"; $go = ($a -eq '' -or $a -match '^[Yy]') }
    if ($go) {
      New-Item -ItemType Directory -Force -Path $newCfg | Out-Null
      foreach ($i in Get-ChildItem -LiteralPath $oc -Force) { if ($i.Name -in 'tmp') { continue }; Copy-Item -LiteralPath $i.FullName -Destination $newCfg -Recurse -Force }
      Write-Host "已複製舊版設定：$oc → $newCfg（舊的保留）。舊專案的 board.json 路徑不變。"
    }
  }
}

# ---------- 複製檔案 ----------
foreach ($f in Get-ChildItem -LiteralPath $payload -Recurse -File -Force) {
  $rel = $f.FullName.Substring($payload.Length).TrimStart('\', '/') -replace '/', '\'
  $dest = Join-Path $target (ConvertTo-OsPath $rel)
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  if (Test-Path -LiteralPath $dest) {
    if ((Get-FileHash -LiteralPath $dest).Hash -eq (Get-FileHash -LiteralPath $f.FullName).Hash) { $stats.same++ }
    else {
      if (-not $installedBefore.ContainsKey($rel) -and -not (Test-Path -LiteralPath "$dest.bak")) { Copy-Item -LiteralPath $dest -Destination "$dest.bak"; $lines.Add("B|$rel"); $stats.backup++ }
      Copy-Item -LiteralPath $f.FullName -Destination $dest -Force; $stats.updated++
    }
  } else { Copy-Item -LiteralPath $f.FullName -Destination $dest; $stats.new++ }
  if (-not $lines.Contains("F|$rel")) { $lines.Add("F|$rel") }
}
[System.IO.File]::WriteAllLines($manifestPath, $lines, [System.Text.UTF8Encoding]::new($false))
Write-Host "已安裝 GuGuBoard 到 $target"
Write-Host "新增 $($stats.new)、更新 $($stats.updated)、相同略過 $($stats.same)、備份 $($stats.backup)"
Write-Host "看板：雙擊 $(Join-Path $target 'start-board.cmd') 啟動；在網頁「新增專案」選專案 repo 資料夾。"
if ($ApplyTo) { & (Join-Path $target 'apply-project.ps1') -RepoPath $ApplyTo -Tools $Tools }
$guide = Join-Path $target 'docs\ai-dev-skills\guide.html'
if (-not $NoOpen -and $IsWindows -ne $false) { Start-Process $guide }
