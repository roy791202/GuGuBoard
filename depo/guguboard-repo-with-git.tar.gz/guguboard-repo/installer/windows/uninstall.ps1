﻿# SPDX-License-Identifier: Apache-2.0
<#
.SYNOPSIS  移除 GuGuBoard：只刪除安裝清單內的檔案，並還原 .bak 備份。.ai-board（帳號與專案設定）保留。可重複執行。
.NOTES     已套用到專案 repo 的檔案不會被移除；要移除請先執行 apply-project.ps1 -RepoPath <repo> -Remove。
#>
[CmdletBinding()]
param([Alias('ProjectPath')][string]$InstallPath = 'D:\AI_PM')
$ErrorActionPreference = 'Stop'
function ConvertTo-OsPath([string]$r) { $r -replace '\\', [IO.Path]::DirectorySeparatorChar }
if (-not (Test-Path $InstallPath)) { Write-Host "資料夾不存在，無需移除：$InstallPath"; return }
$target = (Resolve-Path $InstallPath).Path
$manifestPath = Join-Path $target '.ai-dev-skills-manifest.txt'
if (-not (Test-Path $manifestPath)) { Write-Host "找不到安裝清單，未安裝或已移除。"; return }
$lines = @(Get-Content -LiteralPath $manifestPath -Encoding UTF8)
$dirs = @{}
foreach ($l in $lines | Where-Object { $_ -like 'F|*' }) {
  $p = Join-Path $target (ConvertTo-OsPath $l.Substring(2))
  if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force }
  $d = Split-Path $p; while ($d.Length -gt $target.Length) { $dirs[$d] = $true; $d = Split-Path $d }
}
foreach ($l in $lines | Where-Object { $_ -like 'B|*' }) {
  $p = Join-Path $target (ConvertTo-OsPath $l.Substring(2))
  if (Test-Path -LiteralPath "$p.bak") { Move-Item -LiteralPath "$p.bak" -Destination $p -Force; Write-Host "已還原 $p" }
}
foreach ($d in $dirs.Keys | Sort-Object Length -Descending) {
  if ((Test-Path -LiteralPath $d) -and -not (Get-ChildItem -LiteralPath $d -Force)) { Remove-Item -LiteralPath $d -Force }
}
Remove-Item -LiteralPath $manifestPath -Force
Write-Host "已從 $target 移除 GuGuBoard（.ai-board 設定保留）。"
