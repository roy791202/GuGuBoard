# SPDX-License-Identifier: Apache-2.0
import os
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..'))
V=open('VERSION').read().strip()
comps=[('core','GuGuBoard：看板、使用指南、母版技能與專案範本（必裝）',True)]
o=[r'''Unicode true
ManifestDPIAware true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"\n!include "TextFunc.nsh"
Name "GuGuBoard"
OutFile "dist\GuGuBoard-Setup.exe"
InstallDir "D:\AI_PM"
RequestExecutionLevel user
SetCompressor /SOLID lzma
VIProductVersion "0.1.0.0"
VIAddVersionKey "ProductName" "GuGuBoard"
VIAddVersionKey "FileDescription" "GuGuBoard：AI Dev 進度看板與 AI 開發流程技能"
VIAddVersionKey "FileVersion" "0.1.0"
VIAddVersionKey "LegalCopyright" "GuGuBoard Maintainers"
!define MANI "$INSTDIR\.ai-dev-skills-manifest.txt"
; 登錄機碼沿用舊名（不對使用者顯示），舊版 AI_PM 直接原地升級
!define UKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\AI_PM"
!define OLDUKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\AIDevSkills"
Var OLDCFG
Var MF
!define MUI_ABORTWARNING
!define MUI_ICON "assets\gugu.ico"
!define MUI_UNICON "assets\gugu.ico"
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "開啟使用指南"
!define MUI_FINISHPAGE_RUN_FUNCTION OpenGuide
!define MUI_WELCOMEPAGE_TEXT "將安裝 GuGuBoard：AI Dev 進度看板（含 Git 分頁）、三階段 AI 開發流程技能與各 AI 工具的專案範本。$\r$\n$\r$\nGuGuBoard 是獨立工具，不需要裝在專案裡。要讓專案 repo 使用 Cursor／Claude Code／Codex 等規則與 hooks，請在看板「新增專案」或「帳號 → 套用到專案」操作（會先列出要寫入的檔案，既有檔案先備份 .bak）。$\r$\n$\r$\n偵測到舊版 AI_INSTRUCTIONS 時，可以把帳號與專案設定複製過來（舊的不刪）。"
!define MUI_DIRECTORYPAGE_TEXT_TOP "選擇 GuGuBoard 的安裝資料夾（預設 D:\AI_PM）。不要選專案資料夾；專案設定之後在看板上套用。"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "LICENSE"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "TradChinese"
Function OpenGuide
  ExecShell "open" "$INSTDIR\docs\ai-dev-skills\guide.html"
FunctionEnd
; $R0=relpath -> $R1 "1" if "F|rel" in old manifest
Function InOld
  StrCpy $R1 "0"
  ClearErrors
  FileOpen $R2 "$INSTDIR\.ai-dev-skills-manifest.old" r
  IfErrors done
  loop:
    FileRead $R2 $R3
    IfErrors close
    ${TrimNewLines} $R3 $R3
    StrCmp $R3 "F|$R0" 0 loop
    StrCpy $R1 "1"
  close:
  FileClose $R2
  done:
FunctionEnd
!macro Inst DIR REL SRC
  SetOutPath "$INSTDIR${DIR}"
  ${If} ${FileExists} "$INSTDIR\${REL}"
    StrCpy $R0 "${REL}"
    Call InOld
    ${If} $R1 == "0"
    ${AndIfNot} ${FileExists} "$INSTDIR\${REL}.bak"
      CopyFiles /SILENT "$INSTDIR\${REL}" "$INSTDIR\${REL}.bak"
      FileWrite $MF "B|${REL}$\r$\n"
    ${EndIf}
  ${EndIf}
  File "/oname=$INSTDIR\${REL}" "${SRC}"
  FileWrite $MF "F|${REL}$\r$\n"
!macroend
Section "-pre"
  CreateDirectory "$INSTDIR"
  Delete "$INSTDIR\.ai-dev-skills-manifest.old"
  Rename "${MANI}" "$INSTDIR\.ai-dev-skills-manifest.old"
  FileOpen $MF "${MANI}" w
  ; carry over old backup records
  ClearErrors
  FileOpen $R2 "$INSTDIR\.ai-dev-skills-manifest.old" r
  IfErrors nold
  cl:
    FileRead $R2 $R3
    IfErrors cdone
    StrCpy $R4 $R3 2
    StrCmp $R4 "B|" 0 cl
    FileWrite $MF $R3
    Goto cl
  cdone:
  FileClose $R2
  nold:
  ; 舊版 AI_INSTRUCTIONS 設定遷移：複製 .ai-board（不刪除舊的）
  StrCpy $OLDCFG ""
  ${IfNot} ${FileExists} "$INSTDIR\.ai-board\users.json"
    ReadRegStr $R6 HKCU "${OLDUKEY}" "InstallLocation"
    ${If} $R6 != ""
    ${AndIf} $R6 != $INSTDIR
    ${AndIf} ${FileExists} "$R6\.ai-board\users.json"
      StrCpy $OLDCFG "$R6\.ai-board"
    ${EndIf}
    ${If} $OLDCFG == ""
    ${AndIf} ${FileExists} "D:\AI_INSTRUCTIONS\.ai-board\users.json"
      StrCpy $OLDCFG "D:\AI_INSTRUCTIONS\.ai-board"
    ${EndIf}
    ${If} $OLDCFG != ""
      MessageBox MB_YESNO|MB_ICONQUESTION "找到舊版設定：$OLDCFG$\r$\n（帳號、專案登記、GitHub 登入設定）$\r$\n$\r$\n要複製到 $INSTDIR\.ai-board 嗎？舊資料夾不會被刪除。" /SD IDNO IDNO skipmig
        CreateDirectory "$INSTDIR\.ai-board"
        CopyFiles /SILENT "$OLDCFG\*.*" "$INSTDIR\.ai-board"
        RMDir /r "$INSTDIR\.ai-board\tmp"
      skipmig:
    ${EndIf}
  ${EndIf}
SectionEnd
''']
for i,(c,label,ro) in enumerate(comps):
    o.append(f'Section "{label}" SEC_{c}\n'+('  SectionIn RO\n' if ro else ''))
    for root,_,fs in os.walk(f'build/payload/{c}'):
        for f in sorted(fs):
            src=os.path.join(root,f); rel=os.path.relpath(src,f'build/payload/{c}').replace('/','\\')
            import ntpath; d=ntpath.dirname(rel); o.append(f'  !insertmacro Inst "{chr(92)+d if d else ""}" "{rel}" "{src.replace("/",chr(92))}"\n')
    o.append('SectionEnd\n')
o.append(r'''Section "-post"
  FileClose $MF
  Delete "$INSTDIR\.ai-dev-skills-manifest.old"
  WriteUninstaller "$INSTDIR\uninstall.exe"
  WriteRegStr HKCU "${UKEY}" "DisplayName" "GuGuBoard ($INSTDIR)"
  WriteRegStr HKCU "${UKEY}" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegStr HKCU "${UKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UKEY}" "DisplayVersion" "0.1.0"
  WriteRegStr HKCU "${UKEY}" "Publisher" "GuGuBoard Maintainers"
  WriteRegStr HKCU "${UKEY}" "URLInfoAbout" "https://github.com/roy791202/GuGuBoard"
  WriteRegStr HKCU "${UKEY}" "Contact" "roy791202@gmail.com"
  WriteRegStr HKCU "${UKEY}" "DisplayIcon" "$INSTDIR\gugu.ico"
  SetOutPath "$INSTDIR"
  CreateShortcut "$INSTDIR\啟動看板.lnk" "$INSTDIR\start-board.cmd" "" "$INSTDIR\gugu.ico" 0
  ; 從舊版 AI_PM 升級：移除舊名稱的捷徑
  Delete "$DESKTOP\AI_PM 看板.lnk"
  Delete "$SMPROGRAMS\AI_PM\AI Dev 看板.lnk"
  Delete "$SMPROGRAMS\AI_PM\使用指南.lnk"
  RMDir "$SMPROGRAMS\AI_PM"
  CreateShortcut "$DESKTOP\GuGuBoard.lnk" "$INSTDIR\start-board.cmd" "" "$INSTDIR\gugu.ico" 0
  CreateDirectory "$SMPROGRAMS\GuGuBoard"
  CreateShortcut "$SMPROGRAMS\GuGuBoard\GuGuBoard.lnk" "$INSTDIR\start-board.cmd" "" "$INSTDIR\gugu.ico" 0
  CreateShortcut "$SMPROGRAMS\GuGuBoard\使用指南.lnk" "$INSTDIR\docs\ai-dev-skills\guide.html"
SectionEnd
Section "Uninstall"
  Delete "$INSTDIR\啟動看板.lnk"
  Delete "$DESKTOP\GuGuBoard.lnk"
  Delete "$SMPROGRAMS\GuGuBoard\GuGuBoard.lnk"
  Delete "$SMPROGRAMS\GuGuBoard\使用指南.lnk"
  RMDir "$SMPROGRAMS\GuGuBoard"
  Delete "$DESKTOP\AI_PM 看板.lnk"
  Delete "$SMPROGRAMS\AI_PM\AI Dev 看板.lnk"
  Delete "$SMPROGRAMS\AI_PM\使用指南.lnk"
  RMDir "$SMPROGRAMS\AI_PM"
  ClearErrors
  FileOpen $R2 "$INSTDIR\.ai-dev-skills-manifest.txt" r
  IfErrors fin
  ul:
    FileRead $R2 $R3
    IfErrors uclose
    ${TrimNewLines} $R3 $R3
    StrCpy $R4 $R3 2
    StrCpy $R5 $R3 "" 2
    StrCmp $R4 "F|" 0 +2
      Delete "$INSTDIR\$R5"
    Goto ul
  uclose:
  FileSeek $R2 0
  ub:
    FileRead $R2 $R3
    IfErrors ubend
    ${TrimNewLines} $R3 $R3
    StrCpy $R4 $R3 2
    StrCpy $R5 $R3 "" 2
    StrCmp $R4 "B|" 0 ub
      IfFileExists "$INSTDIR\$R5.bak" 0 ub
      Delete "$INSTDIR\$R5"
      Rename "$INSTDIR\$R5.bak" "$INSTDIR\$R5"
    Goto ub
  ubend:
  FileClose $R2
  fin:
  Delete "$INSTDIR\.ai-dev-skills-manifest.txt"
  Delete "$INSTDIR\uninstall.exe"
  ; .ai-board（帳號與專案設定）保留，不刪除
''')
dirs=set()
for c,_,_ in comps:
    for root,_,_ in os.walk(f'build/payload/{c}'):
        r=os.path.relpath(root,f'build/payload/{c}')
        while r not in ('.',''): dirs.add(r.replace('/','\\')); r=os.path.dirname(r)
for d in sorted(dirs,key=lambda x:-x.count('\\')): o.append(f'  RMDir "$INSTDIR\\{d}"\n')
o.append('  RMDir "$INSTDIR"\n  DeleteRegKey HKCU "${UKEY}"\nSectionEnd\n')
open('build/installer.nsi','w',encoding='utf-8-sig').write(''.join(o).replace('0.1.0.0',V+'.0').replace('"0.1.0"','"'+V+'"'))
