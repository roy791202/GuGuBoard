#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# GuGuBoard AI Hooks 的 sh 入口（macOS／Linux）：找 pwsh 執行 ai-hook.ps1，參數原樣傳入。用法：sh .ai-hooks/ai-hook.sh -Tool claude -Event PreToolUse
PS=$(command -v pwsh || command -v powershell)
[ -z "$PS" ] && { echo "找不到 PowerShell 7（pwsh）。macOS：brew install powershell；Linux：見 https://aka.ms/install-powershell" >&2; exit 2; }
exec "$PS" -NoProfile -File "$(dirname "$0")/ai-hook.ps1" "$@"
