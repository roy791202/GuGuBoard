## 改了什麼 What
<!-- 簡述改動與原因；關聯 issue：Closes # -->

## 怎麼測試 How tested
- [ ] `pwsh tests/parse-check.ps1`
- [ ] `sh tests/unix-install.sh dist` / `pwsh tests/windows-install.ps1`
- [ ] 端對端測試（看板相關改動）

## 檢查清單 Checklist
- [ ] PowerShell 5.1 相容（無 `??`、`?.`、三元、`-AsHashtable`）
- [ ] 沒有放寬安全規則（force push、--no-verify、token 送瀏覽器、默默覆蓋檔案）
- [ ] 沒有加入 CDN 或新相依套件
- [ ] 介面改動附截圖；必要時更新 docs/guide.html 與 CHANGELOG.md
