# 貢獻指南 Contributing

感謝你願意貢獻！ Thanks for contributing!

## 開發環境
- git、Python 3.10+、PowerShell 7（pwsh）；建 exe 需要 NSIS（makensis），建 .deb 需要 dpkg-deb；端對端測試需要 Node 20 與 Chrome。
- 建置：`python3 scripts/build.py`；測試：見 `tests/README.md`。

## 程式規範
- **PowerShell 需相容 Windows PowerShell 5.1**：不要用 `??`、`?.`、三元運算子、`-AsHashtable`（`tests/parse-check.ps1` 會擋）。
- `.ps1` 用 UTF-8 BOM＋CRLF（`enforce/check.ps1`、`enforce/guard.ps1` 例外：LF、無 BOM）；`.sh` 用 LF，且必須是 POSIX sh（`dash -n` 通過）。
- 不加 CDN 或新的執行期相依套件；介面文字以繁體中文為主，並提供英文。
- 安全規則不可放寬：不 force push、不 `--no-verify`、token 不送到瀏覽器、不默默覆蓋專案檔案。

## 流程
1. 先開 issue 討論較大的改動。
2. 從 `main` 開分支，小而專注的 commit（建議 Conventional Commits：`feat:`、`fix:`、`docs:`…）。
3. 確認 CI 全綠，在 PR 說明改了什麼、怎麼測試、有沒有畫面變更（附截圖）。
4. 提交即表示你同意以 Apache-2.0 授權你的貢獻（見 LICENSE 第 5 條）。
