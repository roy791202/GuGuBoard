// SPDX-License-Identifier: Apache-2.0
// 回歸測試：燈號規則 L1–L7 在每一層都擋得住且訊息帶規則編號
//   驗證器 CLI、AI Hook（Claude PreToolUse）、pre-commit（check.ps1）、CI guard（guard.ps1）、前端 lightRule()
//   （伺服器 Agent API 那一層在 aipm-features.test.js）；另測 .ai-pm 保護（hook 擋寫 project.json、pre-commit 擋刪 board.json、>20% 刪除）
// 用法：BASE=http://localhost:8767 node tests/rules-layers.test.js
const cp=require('child_process'),fs=require('fs'),path=require('path'),os=require('os');
const PWSH=process.env.PWSH||'pwsh',BASE=process.env.BASE||'http://localhost:8767',ROOT=path.join(__dirname,'..');
let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
const git=(d,...a)=>cp.execFileSync('git',['-C',d,'-c','user.name=t','-c','user.email=t@t',...a],{encoding:'utf8'});
const ps=(args,o)=>cp.spawnSync(PWSH,['-NoProfile','-File',...args],Object.assign({encoding:'utf8'},o||{}));
const H='2026-11-01T09:00:00+08:00',H2='2026-11-02T09:00:00+08:00';
const task=(id,st,lt,x)=>Object.assign({id,level:'Task',title:'工作 '+id,parentId:'S-1',status:st,light:lt,createdAt:H,updatedAt:H,history:[]},x||{});
const base=()=>({version:1,project:'規則測試',updatedAt:H,revision:1,items:[{id:'S-1',level:'Story',title:'故事',status:'In Progress',light:'Green',createdAt:H,updatedAt:H,history:[]},
  task('T-1','Todo','Gray'),task('T-2','In Progress','Green'),task('T-3','In Review','Green',{tdd:'Green'}),task('T-4','In Progress','Green'),task('T-5','Todo','Gray'),task('T-6','Todo','Gray')]});
const hist=(it,from,to)=>{it.updatedAt=H2;it.history=[...(it.history||[]),{at:H2,from,to,by:'tester',reason:'test'}];};
// 每條規則：改壞的方式（並補 history，讓 L7 以外的規則單獨成立）
const CASES={
  L1:d=>{const i=d.items[1];i.light='Green';hist(i,'Todo / Gray','Todo / Green');},
  L2:d=>{const i=d.items[2];i.light='Gray';hist(i,'In Progress / Green','In Progress / Gray');},
  L3:d=>{const i=d.items[3];i.status='Done';hist(i,'In Review / Green','Done / Green');},
  L4:d=>{const i=d.items[4];i.light='Red';hist(i,'In Progress / Green','In Progress / Red');},
  L5:d=>{const i=d.items[3];i.status='Done';i.light='Blue';hist(i,'In Review / Green','Done / Blue');},
  L6:d=>{const i=d.items[3];i.tdd='Red';hist(i,'In Review / Green','In Review / Green');},
  L7:d=>{const i=d.items[4];i.light='Yellow';i.lightReason='slow';}};
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'rules-'));const vdir=path.join(tmp,'v');fs.mkdirSync(vdir);
for(const f of ['validate-board.ps1'])fs.copyFileSync(path.join(ROOT,'src','hooks',f),path.join(vdir,f));
for(const f of ['check.ps1','guard.ps1'])fs.copyFileSync(path.join(ROOT,'enforce',f),path.join(vdir,f));
function mkrepo(n){const r=path.join(tmp,n);fs.mkdirSync(path.join(r,'.ai-pm'),{recursive:true});git(r,'init','-q');fs.writeFileSync(path.join(r,'.ai-pm','board.json'),JSON.stringify(base(),null,2));fs.writeFileSync(path.join(r,'.ai-pm','project.json'),'{"id":"x"}');git(r,'add','.');git(r,'commit','-q','-m','chore: base');
  const hd=path.join(r,'.ai-hooks');fs.mkdirSync(hd);for(const f of ['ai-hook.ps1','validate-board.ps1','config.json'])fs.copyFileSync(path.join(ROOT,'src','hooks',f),path.join(hd,f));return r;}
(async()=>{
  for(const [rule,mut] of Object.entries(CASES)){
    const d=base();mut(d);const txt=JSON.stringify(d,null,2);const tag='['+rule+']';const role=rule==='L5'?'dev-agent':'';
    // 1 驗證器 CLI
    const o=path.join(tmp,rule+'-old.json'),n=path.join(tmp,rule+'-new.json');fs.writeFileSync(o,JSON.stringify(base(),null,2));fs.writeFileSync(n,txt);
    let v=ps([path.join(vdir,'validate-board.ps1'),'-Path',n,'-OldPath',o].concat(role?['-Role',role]:[]));ok(v.status===1&&(v.stdout+v.stderr).includes(tag),rule+' 驗證器 CLI 擋下 '+(v.stdout+v.stderr).split('\n').find(x=>x.includes(tag))?.trim().slice(0,90));
    // 2 AI Hook（Claude PreToolUse Write）
    const r=mkrepo('h-'+rule);const inp=JSON.stringify({hook_event_name:'PreToolUse',tool_name:'Write',tool_input:{file_path:path.join(r,'.ai-pm','board.json'),content:txt}});
    v=ps([path.join(r,'.ai-hooks','ai-hook.ps1'),'-Tool','claude','-Event','PreToolUse'],{input:inp,cwd:r,env:Object.assign({},process.env,{CLAUDE_PROJECT_DIR:r,AI_AGENT_ROLE:'dev-agent'})});
    const hout=v.stdout+v.stderr;ok((v.status===2||/"deny"|permissionDecision/.test(hout))&&hout.includes(tag),rule+' AI Hook 擋下（exit '+v.status+'）');
    // 3 pre-commit
    fs.writeFileSync(path.join(r,'.ai-pm','board.json'),txt);git(r,'add','.ai-pm/board.json');
    v=ps([path.join(vdir,'check.ps1'),'-Mode','pre-commit'],{cwd:r,env:Object.assign({},process.env,role?{AIPM_ROLE:role}:{})});ok(v.status!==0&&(v.stdout+v.stderr).includes(tag),rule+' pre-commit 擋下');
    // 4 CI guard（L5 是角色規則：CI 看不到是誰改的，由 hook／pre-commit／API 擋，這裡跳過）
    if(rule!=='L5'){const bsha=git(r,'rev-parse','HEAD').trim();git(r,'commit','-q','--no-verify','-m','test: bad board');
      v=ps([path.join(vdir,'guard.ps1')],{cwd:r,env:Object.assign({},process.env,{BASE_SHA:bsha,PR_TITLE:'x',HEAD_REF:'release/x'})});ok(v.status!==0&&(v.stdout+v.stderr).includes(tag),rule+' CI guard 擋下');}
  }
  // .ai-pm 保護
  const r=mkrepo('prot');const env=Object.assign({},process.env,{CLAUDE_PROJECT_DIR:r,AI_AGENT_ROLE:'dev-agent'});
  let v=ps([path.join(r,'.ai-hooks','ai-hook.ps1'),'-Tool','claude','-Event','PreToolUse'],{cwd:r,env,input:JSON.stringify({hook_event_name:'PreToolUse',tool_name:'Write',tool_input:{file_path:path.join(r,'.ai-pm','project.json'),content:'{}'}})});
  ok(v.status===2||/deny/.test(v.stdout),'hook 擋寫入 .ai-pm/project.json');
  v=ps([path.join(r,'.ai-hooks','ai-hook.ps1'),'-Tool','claude','-Event','PreToolUse'],{cwd:r,env,input:JSON.stringify({hook_event_name:'PreToolUse',tool_name:'Bash',tool_input:{command:'rm -rf .ai-pm'}})});
  ok(v.status===2||/deny/.test(v.stdout),'hook 擋 rm -rf .ai-pm');
  const d=base();d.items=d.items.slice(0,4);d.updatedAt=H2;d.revision=2;fs.writeFileSync(path.join(r,'.ai-pm','board.json'),JSON.stringify(d,null,2));git(r,'add','.ai-pm/board.json');
  v=ps([path.join(vdir,'check.ps1'),'-Mode','pre-commit'],{cwd:r});ok(v.status!==0&&/20%|removed/.test(v.stdout+v.stderr),'pre-commit 擋大量刪除且沒有 removed 紀錄');
  const d2=base();d2.revision=0;d2.updatedAt=H2;fs.writeFileSync(path.join(r,'.ai-pm','board.json'),JSON.stringify(d2,null,2));git(r,'add','.ai-pm/board.json');
  v=ps([path.join(vdir,'check.ps1'),'-Mode','pre-commit'],{cwd:r});ok(v.status!==0&&/revision/.test(v.stdout+v.stderr),'pre-commit 擋 revision 倒退');
  git(r,'reset','-q');git(r,'checkout','-q','--','.');git(r,'rm','-q','.ai-pm/board.json');v=ps([path.join(vdir,'check.ps1'),'-Mode','pre-commit'],{cwd:r});ok(v.status!==0,'pre-commit 擋刪除 .ai-pm/board.json');
  // 5 前端 lightRule()
  try{const p=require(process.env.PPT||'puppeteer-core');const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});const pg=await b.newPage();await pg.goto(BASE+'/');
    const res=await pg.evaluate(()=>{const T=(st,lt,x)=>Object.assign({id:'T-9',level:'Task',status:st,light:lt},x||{});return{L1:lightRule(T('Todo','Green')),L2:lightRule(T('In Progress','Gray')),L3:lightRule(T('Done','Green')),L4:lightRule(T('In Progress','Red')),L6:lightRule(T('In Review','Green',{tdd:'Red'})),okp:lightRule(T('In Progress','Gray',{paused:true,pausedReason:'等待'}))};});
    for(const k of ['L1','L2','L3','L4','L6'])ok(res[k].some(x=>x.includes('['+k+']')),k+' 前端 lightRule 同樣擋下');ok(res.okp.length===0,'L2 暫停＋原因的灰燈是合法的');await b.close();}catch(e){ok(false,'前端測試失敗 '+e.message);}
  console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);
})();
