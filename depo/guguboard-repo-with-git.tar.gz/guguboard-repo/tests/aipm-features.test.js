// SPDX-License-Identifier: Apache-2.0
// 回歸測試：.ai-pm 看板、備份還原、搬移、AI 提示詞 A/B、Agent API（claim／lease／heartbeat／release、規則驗證）、token 撤銷、派工器（假 CLI）、
//          整合設定遮罩、外部監看關卡、設定（語言／主題）與三種主題截圖
// 用法：BASE=http://localhost:8767 SHOTDIR=dist node tests/aipm-features.test.js
// 前提：伺服器以 AIPM_LEASE_MIN=0.25 啟動（租約 15 秒），帳號 alice(admin)、dev（密碼 abcdefghijkl1）
const p=require(process.env.PPT||'puppeteer-core');const cp=require('child_process'),fs=require('fs'),path=require('path'),os=require('os');
const BASE=process.env.BASE||'http://localhost:8767',SHOTDIR=process.env.SHOTDIR||'',PWSH=process.env.PWSH||'pwsh';
const W=ms=>new Promise(r=>setTimeout(r,ms));let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
const git=(d,...a)=>cp.execFileSync('git',['-C',d,...a],{encoding:'utf8'});
async function login(b,u){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:1400,height:900});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));pg.on('dialog',d=>d.accept());
  await pg.goto(BASE+'/');await W(600);await pg.evaluate(()=>localStorage.clear());await pg.click('#localLink').catch(()=>{});await pg.type('#lu',u);await pg.type('#lp','abcdefghijkl1');await pg.click('#localSec button[type=submit]');await W(1500);return pg;}
const post=(pg,url,body)=>pg.evaluate(async(u,b)=>{const r=await fetch(u,{method:'POST',headers:{'X-Board-Request':'1','Content-Type':'application/json'},body:JSON.stringify(b)});return{s:r.status,j:await r.json().catch(()=>null)};},url,body);
const get=(pg,url)=>pg.evaluate(async u=>{const r=await fetch(u);return{s:r.status,j:await r.json().catch(()=>null)};},url);
async function ag(tok,m,sub,body,hdr){const r=await fetch(BASE+'/api/agent/v1'+sub,{method:m,headers:Object.assign({Authorization:'Bearer '+tok,'Content-Type':'application/json'},hdr||{}),body:body?JSON.stringify(body):undefined});return{s:r.status,j:await r.json().catch(()=>null)};}
const H='2026-11-01T09:00:00+08:00';
const task=(id,st,lt,x)=>Object.assign({id,level:'Task',title:'工作 '+id,parentId:'S-1',status:st,light:lt,estimate:{hours:2},createdAt:H,updatedAt:H,history:[]},x||{});
function seed(){return{version:1,project:'功能測試',updatedAt:H,items:[{id:'S-1',level:'Story',title:'故事',status:'Todo',light:'Gray',createdAt:H,updatedAt:H,history:[]},
  task('T-1','Todo','Gray'),task('T-2','Todo','Gray'),task('T-3','Todo','Gray',{dependsOn:['T-1']}),task('T-4','In Review','Green',{tdd:'Green'})]};}
(async()=>{const T=Date.now().toString(36).slice(-5);const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});
  const pg=await login(b,'alice');
  // 1 新專案預設 .ai-pm/
  const repo=path.join(os.tmpdir(),'aipm-t','feat-'+T);fs.mkdirSync(repo,{recursive:true});git(repo,'init','-q');git(repo,'-c','user.name=t','-c','user.email=t@t','commit','-q','--allow-empty','-m','chore: init');
  const pid='ft-'+T;let r=await post(pg,'api/projects',{id:pid,name:'功能測試',repoPath:repo});ok(r.s===200,'建立專案 '+r.s);
  const bp=path.join(repo,'.ai-pm','board.json');ok(fs.existsSync(bp)&&fs.existsSync(path.join(repo,'.ai-pm','project.json'))&&fs.existsSync(path.join(repo,'.ai-pm','README.md')),'看板在 .ai-pm/（含 project.json、README.md）');
  const gi=fs.existsSync(path.join(repo,'.ai-pm','.gitignore'))?fs.readFileSync(path.join(repo,'.ai-pm','.gitignore'),'utf8'):(fs.existsSync(path.join(repo,'.gitignore'))?fs.readFileSync(path.join(repo,'.gitignore'),'utf8'):'');ok(/backups/.test(gi)&&/runs/.test(gi),'backups/、runs/ 已加入 .gitignore');
  fs.writeFileSync(bp,JSON.stringify(seed(),null,2));await W(2500);
  // 2 AI 提示詞
  r=await post(pg,'api/p/'+pid+'/agent/prompt',{role:'dev-agent',ticket:'T-1',mode:'A'});ok(r.s===200&&/AGENTS\.md/.test(r.j.prompt)&&/T-1/.test(r.j.prompt)&&!/gh[po]_|github_pat|aipm_/.test(r.j.prompt),'模式 A 短提示詞（不含任何 token）');
  r=await post(pg,'api/p/'+pid+'/agent/prompt',{role:'dev-agent',mode:'B',days:1,agentName:'devbot'});const tokA=(r.j&&r.j.prompt.match(/aipm_[0-9a-f]{8}_[A-Za-z0-9_-]+/)||[])[0];ok(r.s===200&&tokA&&!/gh[po]_|github_pat/.test(r.j.prompt),'模式 B 附 Agent API 與 token');
  r=await post(pg,'api/p/'+pid+'/agent/prompt',{role:'dev-agent',mode:'B',agentName:'devbot2'});const tokB=(r.j.prompt.match(/aipm_[0-9a-f]{8}_[A-Za-z0-9_-]+/)||[])[0];
  r=await post(pg,'api/p/'+pid+'/agent/prompt',{role:'verifier',mode:'B',agentName:'verbot'});const tokV=(r.j.prompt.match(/aipm_[0-9a-f]{8}_[A-Za-z0-9_-]+/)||[])[0];
  r=await post(pg,'api/p/'+pid+'/agent/prompt',{role:'admin',mode:'B'});ok(r.s===400,'token 不能是 admin 角色');
  const store=fs.readFileSync(path.join(process.env.CFG||path.join(process.env.AIPM||'.','.ai-board'),'agent-tokens.json'),'utf8').toString();ok(!store.includes(tokA)&&!store.includes(tokA.slice(14))&&tokA.slice(14).length>=20,'token 只存雜湊');
  // 3 Agent API
  let a=await ag(tokA,'GET','/bootstrap');ok(a.s===200&&Array.isArray(a.j.rules)&&a.j.rules.some(x=>/\[L7\]/.test(x)),'bootstrap 含 L1–L7 規則');
  a=await ag('aipm_00000000_bad','GET','/me');ok(a.s===401,'錯誤 token 401');
  a=await ag(tokA,'GET','/tickets');ok(a.s===200&&a.j.tickets.length>=4,'GET tickets');
  a=await ag(tokA,'POST','/claim',{});ok(a.s===200&&a.j.ticket==='T-1','claim 拿到第一張可領的 T-1 '+JSON.stringify(a.j));
  a=await ag(tokB,'POST','/claim',{ticket:'T-1'});ok(a.s===409,'另一個代理不能重複領取 T-1');
  a=await ag(tokB,'POST','/claim',{});ok(a.j.ticket==='T-2','另一個代理改拿 T-2（T-3 相依 T-1 未完成）'+a.j.ticket);
  a=await ag(tokB,'PATCH','/tickets/T-1',{status:'In Progress',light:'Green',reason:'x'});ok(a.s===409,'不能改別人領取的工單');
  a=await ag(tokA,'PATCH','/tickets/T-1',{status:'In Progress',light:'Gray',reason:'start'});ok(a.s===422&&JSON.stringify(a.j).includes('[L2]'),'[L2] API 擋 In Progress 灰燈');
  a=await ag(tokA,'PATCH','/tickets/T-1',{light:'Green',reason:'x'});ok(a.s===422&&JSON.stringify(a.j).includes('[L1]'),'[L1] API 擋 Todo 綠燈');
  a=await ag(tokA,'PATCH','/tickets/T-1',{status:'In Progress',light:'Red',reason:'x'});ok(a.s===422&&JSON.stringify(a.j).includes('[L4]'),'[L4] API 擋紅燈沒有原因');
  a=await ag(tokA,'PATCH','/tickets/T-1',{status:'Done',light:'Blue',reason:'x'});ok(a.s===422&&JSON.stringify(a.j).includes('[L5]'),'[L5] API 擋開發代理移到 Done');
  a=await ag(tokA,'PATCH','/tickets/T-1',{status:'In Review',light:'Green',tdd:'Red',reason:'x'});ok(a.s===422&&JSON.stringify(a.j).includes('[L6]'),'[L6] API 擋 In Review 綠燈但測試紅');
  a=await ag(tokA,'PATCH','/tickets/T-1',{status:'In Progress',light:'Green'});ok(a.s===422&&JSON.stringify(a.j).includes('[L7]'),'[L7] API 要求 reason');
  a=await ag(tokA,'PATCH','/tickets/T-1',{status:'In Progress',light:'Green',reason:'開始實作',note:'claim ok'});ok(a.s===200&&a.j.ticket.status==='In Progress','合法 PATCH 寫入並留 history');
  a=await ag(tokV,'PATCH','/tickets/T-4',{status:'Done',light:'Green',reason:'x'});ok(a.s===422&&JSON.stringify(a.j).includes('[L3]'),'[L3] API 擋 Done 非藍燈');
  const bd=JSON.parse(fs.readFileSync(bp,'utf8'));const t1=bd.items.find(i=>i.id==='T-1');ok(t1.history.length===1&&t1.history[0].reason==='開始實作'&&bd.revision>=1,'board.json 寫入 history 與 revision');
  a=await ag(tokA,'POST','/heartbeat',{ticket:'T-1'});ok(a.s===200,'heartbeat 延長租約');
  r=await get(pg,'api/p/'+pid+'/claims');ok(r.j.claims.length===2,'看板看得到 2 張領取中');
  await pg.goto(BASE+'/?p='+pid);await W(2500);ok(await pg.$$eval('#board .clm',e=>e.length)===2,'卡片顯示 🤖 領取標記');
  a=await ag(tokB,'POST','/release',{ticket:'T-2'});ok(a.s===200,'release');
  await W(17000);a=await ag(tokA,'POST','/heartbeat',{ticket:'T-1'});ok(a.s===409,'租約過期自動釋放（heartbeat 409）');
  a=await ag(tokB,'POST','/claim',{ticket:'T-1'});ok(a.s===200&&a.j.ticket==='T-1','過期後別人可以領 T-1');await ag(tokB,'POST','/release',{ticket:'T-1'});
  // 4 token 管理與撤銷
  r=await get(pg,'api/p/'+pid+'/agent-tokens');const rec=r.j.tokens.find(x=>x.name==='devbot');ok(rec&&rec.role==='dev-agent','token 清單');
  r=await post(pg,'api/p/'+pid+'/agent-tokens',{action:'revoke',id:rec.id});a=await ag(tokA,'GET','/me');ok(r.s===200&&a.s===401,'撤銷後 token 失效');
  const pd=await login(b,'dev');r=await get(pd,'api/p/'+pid+'/agent-tokens');ok(r.s===403,'非管理者看不到 token 清單');
  // 5 備份與還原
  r=await get(pg,'api/p/'+pid+'/backups');ok(r.s===200&&r.j.backups.length>=1,'有自動備份 '+(r.j.backups||[]).length);
  const bk=r.j.backups[0].name;r=await post(pg,'api/p/'+pid+'/restore',{source:'backup',name:bk});ok(r.s===200,'從備份還原 '+r.s);
  r=await post(pg,'api/p/'+pid+'/restore',{source:'backup',name:'../../x.json'});ok(r.s===400,'備份檔名不能跳出資料夾');
  git(repo,'add','-A');git(repo,'-c','user.name=t','-c','user.email=t@t','commit','-q','-m','chore: board');const sha=git(repo,'rev-parse','HEAD').trim();
  r=await post(pg,'api/p/'+pid+'/restore',{source:'git',sha});ok(r.s===200,'從 git 版本還原');
  await pg.goto(BASE+'/?p='+pid);await W(2000);await pg.click('#histBtn');await W(800);ok(!!await pg.$('#bkBtn'),'歷史面板有「備份與還原…」');await pg.click('#bkBtn');await W(1200);ok(await pg.$$eval('#bkList .bkr',e=>e.length)>=1,'備份清單顯示還原按鈕');await pg.evaluate(()=>gClose());
  // 6 舊 docs/ 專案搬到 .ai-pm
  const r2=path.join(os.tmpdir(),'aipm-t','legacy-'+T);fs.mkdirSync(path.join(r2,'docs'),{recursive:true});git(r2,'init','-q');fs.writeFileSync(path.join(r2,'docs','board.json'),JSON.stringify(seed(),null,2));git(r2,'add','.');git(r2,'-c','user.name=t','-c','user.email=t@t','commit','-q','-m','chore: legacy');
  r=await post(pg,'api/projects',{id:'lg-'+T,name:'舊專案',repoPath:r2});ok(r.s===200&&!fs.existsSync(path.join(r2,'.ai-pm','board.json')),'舊專案沿用 docs/board.json（不另建分岔）');
  await pg.goto(BASE+'/?p=lg-'+T);await W(2000);await pg.click('#admBtn');await W(1500);ok(!!await pg.$('#migBtn'),'管理面板顯示「搬到 .ai-pm/」');
  r=await post(pg,'api/p/lg-'+T+'/migrate-aipm',{commit:true});ok(r.s===200&&r.j.gitMv&&fs.existsSync(path.join(r2,'.ai-pm','board.json'))&&!fs.existsSync(path.join(r2,'docs','board.json')),'git mv 搬移 '+JSON.stringify(r.j));
  ok(/GuGuBoard|ai-pm/i.test(git(r2,'log','-1','--format=%s'))&&git(r2,'status','--porcelain').trim()==='','勾選 commit 後已提交');
  // 7 派工器（假 CLI）
  const fk=path.join(os.tmpdir(),'aipm-fake');fs.mkdirSync(fk,{recursive:true});fs.copyFileSync(path.join(__dirname,'fixtures','fake-cli.ps1'),path.join(fk,'fake-cli.ps1'));
  const prof={id:'fake',label:'Fake',exe:PWSH,args:['-NoProfile','-File',path.join(fk,'fake-cli.ps1'),'{prompt}'],role:'dev-agent',timeoutMin:1};
  r=await post(pg,'api/p/'+pid+'/dispatch/config',{profiles:[{id:'x',exe:'cmd & del',args:[],role:'dev-agent'}]});ok(r.s===400,'profile exe 不能含 shell 符號');
  r=await post(pg,'api/p/'+pid+'/dispatch/config',{profiles:[prof],profile:'fake'});ok(r.s===200,'設定 profile');
  r=await post(pg,'api/p/'+pid+'/dispatch/config',{profiles:[Object.assign({},prof,{role:'high-tier'})]});ok(r.s===400,'派工器不能啟動高階角色');
  r=await get(pg,'api/p/'+pid+'/dispatch');ok(r.j.config.enabled===false,'派工器預設關閉');
  fs.writeFileSync(path.join(fk,'fake-mode.txt'),'approve');r=await post(pg,'api/p/'+pid+'/dispatch/config',{enabled:true,intervalSec:5,maxConcurrent:1});
  let run=null;for(let k=0;k<30&&!run;k++){await W(1500);r=await get(pg,'api/p/'+pid+'/dispatch');run=(r.j.runs||[]).find(x=>x.status!=='running');}
  let log=run?await pg.evaluate(async u=>(await fetch(u)).text(),'api/p/'+pid+'/dispatch/log/'+run.id+'.log'):'';ok(run&&/APPROVE-DENIED 422/.test(log)&&/promptHasToken=False/.test(log),'派工 token 不能核准 Done，提示詞不含 token '+(run&&run.status));
  r=await post(pg,'api/p/'+pid+'/dispatch/config',{enabled:false});
  fs.writeFileSync(path.join(fk,'fake-mode.txt'),'sleep');await post(pg,'api/p/'+pid+'/dispatch/config',{enabled:true});
  let rn=null;for(let k=0;k<20&&!rn;k++){await W(1500);r=await get(pg,'api/p/'+pid+'/dispatch');rn=(r.j.runs||[]).find(x=>x.status==='running');}
  ok(!!rn,'派工啟動執行中');await post(pg,'api/p/'+pid+'/dispatch/config',{enabled:false});
  r=await post(pg,'api/p/'+pid+'/dispatch/kill',{run:rn&&rn.id});await W(1500);r=await get(pg,'api/p/'+pid+'/dispatch');ok((r.j.runs.find(x=>x.id===(rn&&rn.id))||{}).status==='killed','停止按鈕終止執行');
  await pg.goto(BASE+'/?p='+pid);await W(1500);await pg.click('#admBtn');await W(2000);ok(await pg.$$eval('#runList tr',e=>e.length)>=2,'管理面板顯示執行紀錄');await pg.click('#runList .runl');await W(800);ok(/FAKE/.test(await pg.$eval('#runLog',e=>e.textContent)),'UI 看得到 log');
  fs.writeFileSync(path.join(fk,'fake-mode.txt'),'red');await post(pg,'api/p/'+pid+'/dispatch/config',{enabled:true});
  let st=null;for(let k=0;k<40&&!st;k++){await W(1500);r=await get(pg,'api/p/'+pid+'/dispatch');st=r.j.config.stoppedReason;}
  ok(st&&/紅燈/.test(st)&&r.j.config.enabled===false,'紅燈時派工器自動停止 '+st);
  // 8 整合設定：密鑰遮罩、外部監看
  r=await post(pg,'api/admin/integrations',{notify:{enabled:false,smtpPassword:'secret-123',chatWebhook:'https://chat.googleapis.com/v1/x'},external:{enabled:false,publicUrl:'https://board.example.com'}});
  ok(r.s===200&&!JSON.stringify(r.j).includes('secret-123')&&!JSON.stringify(r.j).includes('chat.googleapis'),'密鑰不回傳到瀏覽器');
  r=await post(pg,'api/admin/integrations',{notify:{chatWebhook:'http://x'}});ok(r.s===400,'webhook 必須 https');
  let ex=await fetch(BASE+'/api/status',{headers:{'X-Forwarded-For':'1.2.3.4'}});ok(ex.status===403,'外部監看未啟用時外部請求一律 403');
  await post(pg,'api/admin/integrations',{external:{enabled:true,publicUrl:'https://board.example.com',googleClientId:'cid'}});
  ex=await fetch(BASE+'/api/status',{headers:{'X-Forwarded-For':'1.2.3.4'}});const ej=await ex.json();ok(ex.status===200&&ej.external&&ej.google,'外部啟用後可看登入頁並顯示 Google 登入');
  ex=await fetch(BASE+'/api/login',{method:'POST',headers:{'X-Forwarded-For':'1.2.3.4','X-Board-Request':'1','Content-Type':'application/json'},body:'{"username":"alice","password":"abcdefghijkl1"}'});ok(ex.status===403,'外部不能用本機密碼登入或寫入');
  ex=await fetch(BASE+'/api/agent/v1/me',{headers:{'X-Forwarded-For':'1.2.3.4',Authorization:'Bearer '+tokV}});ok(ex.status===403,'外部不能用 Agent API');
  await post(pg,'api/admin/integrations',{external:{enabled:false}});
  // 9 設定：語言、主題、偏好存在伺服器
  await pg.goto(BASE+'/?p='+pid);await W(2000);await pg.click('#setBtn');await W(500);await pg.select('#setLang','en');await W(300);
  ok(/Board/.test(await pg.$eval('#tabBoard',e=>e.textContent)),'切換英文');await pg.select('#setLang','zh-CN');await W(300);ok(/图表/.test(await pg.$eval('#tabChart',e=>e.textContent)),'切換簡體');
  await pg.select('#setLang','zh-TW');for(const th of ['light','gray','dark','gugu']){await pg.click('input[name=setTheme][value='+th+']');await W(400);if(th!=='light'||true){await pg.evaluate(()=>gClose());await W(300);if(SHOTDIR)await pg.screenshot({path:path.join(SHOTDIR,'board-theme-'+th+'-screenshot.png')});await pg.click('#setBtn');await W(300);}}
  await pg.click('input[name=setTheme][value=dark]');await W(300);const bg=await pg.evaluate(()=>getComputedStyle(document.body).backgroundColor);ok(bg==='rgb(13, 17, 23)','深色主題套用 CSS 變數 '+bg);
  await pg.click('#setSave');await W(800);const pr=await get(pg,'api/me');ok(pr.j.prefs&&pr.j.prefs.theme==='dark','偏好存在伺服器');
  await pg.click('#tabChart');await W(800);if(SHOTDIR)await pg.screenshot({path:path.join(SHOTDIR,'board-theme-dark-gantt-screenshot.png')});
  await post(pg,'api/me/prefs',{lang:'zh-TW',theme:'light'});
  // 10 AI 提示詞 UI
  await pg.goto(BASE+'/?p='+pid);await W(2000);await pg.click('#aiBtn');await W(500);await pg.click('#apGo');await W(1000);ok(/AGENTS\.md/.test(await pg.$eval('#apOut',e=>e.value)),'「🤖 AI 提示詞」產生提示詞');
  ok(pg.errs.length===0&&pd.errs.length===0,'沒有 JS 錯誤 '+pg.errs.concat(pd.errs).join('|'));
  await b.close();console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1);});
