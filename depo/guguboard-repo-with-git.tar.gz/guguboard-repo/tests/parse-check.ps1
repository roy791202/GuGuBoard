﻿# SPDX-License-Identifier: Apache-2.0
# 所有 .ps1 的語法檢查，並確認沒有 PowerShell 5.1 不支援的語法（??、?.、三元運算子、-AsHashtable）
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$bad = 0
Get-ChildItem -Path $root -Recurse -Force -Filter *.ps1 | Where-Object { $_.FullName -notmatch '[\\/](\.git|build|dist|node_modules)[\\/]' } | ForEach-Object {
  $raw = [IO.File]::ReadAllBytes($_.FullName)
  if ($raw.Length -lt 3 -or $raw[0] -ne 0xEF -or $raw[1] -ne 0xBB -or $raw[2] -ne 0xBF) { $bad++; Write-Host "FAIL $($_.FullName): 缺 UTF-8 BOM（Windows PowerShell 5.1 會用系統碼頁解碼而解析失敗）" }
  $tokens = $null; $errs = $null
  $ast = [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$tokens, [ref]$errs)
  if ($errs.Count) { $bad++; Write-Host "FAIL $($_.FullName): $($errs[0].Message)" }
  $t = Get-Content -Raw -LiteralPath $_.FullName
  if ($_.Name -ne 'parse-check.ps1' -and $t -match ('-As' + 'Hashtable')) { $bad++; Write-Host "FAIL $($_.Name): -AsHashtable（PS 5.1 不支援）" }
  foreach ($tk in $tokens) { if ($tk.Kind -in 'QuestionQuestion','QuestionDot','QuestionQuestionEquals','QuestionMark') { $bad++; Write-Host "FAIL $($_.Name):$($tk.Extent.StartLineNumber) PS 7 專用語法 $($tk.Text)"; break } }
}
if ($bad) { exit 1 } else { Write-Host '全部通過' }
