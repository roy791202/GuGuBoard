﻿# SPDX-License-Identifier: Apache-2.0
# PowerShell 安裝冒煙測試（Windows PowerShell 5.1／pwsh 7）：解壓 GuGuBoard-PowerShell.zip → install.ps1 → 套用到暫時 repo → uninstall.ps1
# 用法：pwsh -File tests/windows-install.ps1 [-Dist dist]
param([string]$Dist = 'dist')
$ErrorActionPreference = 'Stop'
function Ok($m) { Write-Host "PASS $m" }
function Fail($m) { Write-Host "FAIL $m"; exit 1 }
$tmp = Join-Path ([IO.Path]::GetTempPath()) ('gugu-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Path $tmp | Out-Null
Expand-Archive -Path (Join-Path $Dist 'GuGuBoard-PowerShell.zip') -DestinationPath (Join-Path $tmp 'zip')
$inst = Join-Path $tmp 'AI_PM'; $repo = Join-Path $tmp 'repo'
New-Item -ItemType Directory -Path $repo | Out-Null
git -C $repo init -q; git -C $repo -c user.name=t -c user.email=t@example.invalid commit -q --allow-empty -m init
& (Join-Path $tmp 'zip/install.ps1') -InstallPath $inst -Migrate no -NoOpen -ApplyTo $repo -Tools Cursor,Claude,Hooks,GitHooks
if (-not (Test-Path (Join-Path $inst 'serve-board.ps1'))) { Fail 'serve-board.ps1 未安裝' }; Ok 'install.ps1'
if (-not (Test-Path (Join-Path $inst 'LICENSE'))) { Fail 'LICENSE 未隨附' }; Ok 'LICENSE 隨附'
if (-not (Test-Path (Join-Path $repo '.cursor/hooks.json'))) { Fail 'hooks.json 未套用' }; Ok '套用到 repo'
if ((git -C $repo config core.hooksPath) -ne '.githooks') { Fail 'core.hooksPath' }; Ok 'core.hooksPath'
& (Join-Path $inst 'apply-project.ps1') -RepoPath $repo -Plan | Out-Null; Ok 'apply-project -Plan'
& (Join-Path $tmp 'zip/uninstall.ps1') -InstallPath $inst
if (Test-Path (Join-Path $inst 'serve-board.ps1')) { Fail 'uninstall 沒刪檔' }; Ok 'uninstall.ps1'
Remove-Item -Recurse -Force $tmp; Write-Host '全部通過'
