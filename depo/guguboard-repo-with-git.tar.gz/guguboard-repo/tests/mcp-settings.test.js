// SPDX-License-Identifier: Apache-2.0
// 設定頁 MCP 區塊：開關、建立 token、各 AI 工具設定範例、撤銷；三種語言與四種主題都能顯示
// 用法：BASE=http://localhost:8767 node tests/mcp-settings.test.js（需要 puppeteer-core 與 Chrome）
const p=require(process.env.PPT||'puppeteer-core');
const BASE=process.env.BASE||'http://localhost:8767',SHOTDIR=process.env.SHOTDIR||'';
const W=ms=>new Promise(r=>setTimeout(r,ms));let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
(async()=>{const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});
  const pg=await b.newPage();await pg.setViewport({width:1400,height:1000});const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept());
  await pg.goto(BASE+'/');await W(600);await pg.evaluate(()=>localStorage.clear());await pg.click('#localLink').catch(()=>{});
  await pg.type('#lu','alice');await pg.type('#lp','abcdefghijkl1');await pg.click('#localSec button[type=submit]');await W(1500);
  const open=async()=>{await pg.click('#setBtn');await pg.waitForSelector('#mcpOn',{timeout:5000});await W(300);};
  await open();ok(!!await pg.$('#mcpSet'),'設定頁有 MCP 區塊');
  await pg.evaluate(()=>{const c=document.getElementById('mcpOn');if(!c.checked)c.click();});await pg.click('#mcpSave');await W(500);
  const st=await pg.evaluate(async()=>(await (await fetch('api/admin/integrations')).json()).settings.mcp);ok(st&&st.enabled===true,'開關存到伺服器');
  await pg.type('#mcpName','ui-claude');await pg.click('#mcpMake');await W(800);
  const sn=await pg.$eval('#mcpSnippet',e=>e.value);const tok=(sn.match(/aipm_[0-9a-f]{8}_[A-Za-z0-9_-]+/)||[])[0];ok(!!tok&&sn.includes('claude mcp add --transport http guguboard'),'建立 token 後 Claude Code 範例帶入 token');
  const r=await fetch(BASE+'/mcp',{method:'POST',headers:{Authorization:'Bearer '+tok,'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/list'})});const j=await r.json();
  ok(r.status===200&&j.result.tools.length>=14,'設定頁建立的 token 可以用 MCP');
  for(const c of ['claude-desktop','cursor','codex','gemini','http']){await pg.select('#mcpClient',c);const v=await pg.$eval('#mcpSnippet',e=>e.value);
    const want={'claude-desktop':'"mcpServers"',cursor:'mcp install cursor',codex:'[mcp_servers.guguboard]',gemini:'"httpUrl"',http:'/mcp'}[c];ok(v.includes(want),c+' 設定範例');}
  if(SHOTDIR)await pg.screenshot({path:SHOTDIR+'/board-mcp-settings-screenshot.png'});
  const rows=await pg.$$eval('#mcpTokens tr',t=>t.length);ok(rows>=1,'token 清單 '+rows+' 筆');
  await pg.evaluate(()=>{const t=[...document.querySelectorAll('#mcpTokens tr')].find(r=>r.textContent.includes('ui-claude'));t.querySelector('button').click();});await W(800);
  const r2=await fetch(BASE+'/mcp',{method:'POST',headers:{Authorization:'Bearer '+tok,'Content-Type':'application/json'},body:'{"jsonrpc":"2.0","id":1,"method":"ping"}'});ok(r2.status===401,'撤銷後 token 失效');
  for(const [lang,word] of [['en','Enable MCP'],['zh-CN','启用 MCP'],['zh-TW','啟用 MCP']]){await pg.select('#setLang',lang);await W(300);const t=await pg.$eval('#mcpSet',e=>e.textContent);ok(t.includes(word),'語言 '+lang+'：'+word);}
  for(const th of ['light','gray','dark','gugu']){await pg.evaluate(v=>document.querySelector('input[name=setTheme][value='+v+']').click(),th);await W(200);
    const c=await pg.$eval('#mcpSnippet',e=>{const s=getComputedStyle(e);return s.color+'|'+s.backgroundColor;});const [fg,bg]=c.split('|');ok(fg!==bg,'主題 '+th+' 文字可讀（'+c+'）');
    if(SHOTDIR&&th==='gugu')await pg.screenshot({path:SHOTDIR+'/board-mcp-settings-gugu-screenshot.png'});}
  await pg.evaluate(()=>{const c=document.getElementById('mcpOn');if(c.checked)c.click();});await pg.click('#mcpSave');await W(400);
  ok(!errs.length,'沒有前端錯誤 '+errs.join('; '));
  await b.close();console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);})().catch(e=>{console.error(e);process.exit(1);});
