﻿# SPDX-License-Identifier: Apache-2.0
# 測試用假 CLI：用環境變數的 token 呼叫 Agent API；模式由 FAKE_MODE 檔決定（ok / sleep / red / approve）
param([string]$Prompt)
$api = $env:AIPM_API; $H = @{ Authorization = "Bearer $env:AIPM_AGENT_TOKEN" }; $t = $env:AIPM_TICKET
$mode = 'ok'; $mf = Join-Path $PSScriptRoot 'fake-mode.txt'; if (Test-Path $mf) { $mode = (Get-Content $mf -Raw).Trim() }
Write-Output "FAKE start ticket=$t mode=$mode promptHasToken=$($Prompt -cmatch 'aipm_[0-9a-f]{8}_')"
Invoke-RestMethod "$api/bootstrap" -Headers $H | Out-Null
if ($mode -eq 'sleep') { Start-Sleep 600 }
if ($mode -eq 'approve') { try { Invoke-RestMethod "$api/tickets/$t" -Method Patch -Headers $H -ContentType 'application/json' -Body '{"status":"Done","light":"Blue","reason":"try"}' | Out-Null; Write-Output 'APPROVE-ALLOWED' } catch { Write-Output "APPROVE-DENIED $($_.Exception.Response.StatusCode.value__)" } }
if ($mode -eq 'red') { Invoke-RestMethod "$api/tickets/$t" -Method Patch -Headers $H -ContentType 'application/json' -Body '{"status":"In Progress","light":"Red","lightReason":"blocked by env","reason":"blocker"}' | Out-Null }
if ($mode -eq 'ok') { Invoke-RestMethod "$api/tickets/$t" -Method Patch -Headers $H -ContentType 'application/json' -Body '{"status":"In Progress","light":"Green","reason":"start"}' | Out-Null }
Invoke-RestMethod "$api/report" -Method Post -Headers $H -ContentType 'application/json' -Body (@{ ticket = $t; summary = "fake $mode"; release = $true } | ConvertTo-Json) | Out-Null
Write-Output 'FAKE end'
