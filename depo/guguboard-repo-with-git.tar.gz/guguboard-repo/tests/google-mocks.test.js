// SPDX-License-Identifier: Apache-2.0
// 回歸測試（mock）：Google Sheets 單向同步（假的 token／Sheets API）、Gmail SMTP 通知（假 SMTP 伺服器）
// 用法：BASE=http://localhost:8767 node tests/google-mocks.test.js（伺服器要能連到 127.0.0.1:9911／9925）
const p=require(process.env.PPT||'puppeteer-core');const http=require('http'),net=require('net');
const BASE=process.env.BASE||'http://localhost:8767';const W=ms=>new Promise(r=>setTimeout(r,ms));let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
const seen=[];const api=http.createServer((q,s)=>{let b='';q.on('data',c=>b+=c);q.on('end',()=>{seen.push({m:q.method,u:q.url,a:q.headers.authorization||'',b});s.setHeader('Content-Type','application/json');
  if(q.url==='/token')return s.end(JSON.stringify({access_token:'ya29.mock',expires_in:3600}));if(/fields=sheets/.test(q.url))return s.end(JSON.stringify({sheets:[{properties:{title:'items'}}]}));s.end('{}');});}).listen(9911);
const mails=[];const smtp=net.createServer(c=>{let data=false,buf='';c.write('220 mock\r\n');c.on('data',d=>{buf+=d.toString();let i;while((i=buf.indexOf('\r\n'))>=0){const l=buf.slice(0,i);buf=buf.slice(i+2);
  if(data){if(l==='.'){data=false;c.write('250 ok\r\n');}else mails[mails.length-1]+=l+'\n';continue;}
  if(/^(EHLO|HELO)/i.test(l))c.write('250 mock\r\n');else if(/^DATA/i.test(l)){data=true;mails.push('');c.write('354 go\r\n');}else if(/^QUIT/i.test(l)){c.write('221 bye\r\n');c.end();}else c.write('250 ok\r\n');}});}).listen(9925);
(async()=>{const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});const ctx=await b.createBrowserContext();const pg=await ctx.newPage();
  await pg.goto(BASE+'/');await W(500);await pg.click('#localLink').catch(()=>{});await pg.type('#lu','alice');await pg.type('#lp','abcdefghijkl1');await pg.click('#localSec button[type=submit]');await W(1500);
  const post=(u,x)=>pg.evaluate(async(u,x)=>{const r=await fetch(u,{method:'POST',headers:{'X-Board-Request':'1','Content-Type':'application/json'},body:JSON.stringify(x)});return{s:r.status,j:await r.json().catch(()=>null)};},u,x);
  const me=await pg.evaluate(async()=>(await fetch('api/me')).json());const pid=me.projects[me.projects.length-1].id;
  let r=await post('api/admin/integrations',{sheets:{enabled:true,clientId:'cid',clientSecret:'csec',refreshToken:'rtok',tokenUrl:'http://127.0.0.1:9911/token',apiBase:'http://127.0.0.1:9911',intervalSec:'99999',projects:{[pid]:'mockSheet_1234567890'}},test:'sheets'});
  const res=(r.j&&r.j.test||[]).find(x=>x.project===pid)||{};ok(r.s===200&&res.ok,'Sheets 同步成功 '+JSON.stringify(res));
  const up=seen.find(x=>/values:batchUpdate/.test(x.u));ok(up&&up.a==='Bearer ya29.mock'&&/items!A1/.test(up.b)&&/sprints!A1/.test(up.b)&&/history!A1/.test(up.b),'寫入 items／sprints／history 三個分頁');
  ok(seen.some(x=>/batchUpdate$/.test(x.u.split('?')[0])&&/addSheet/.test(x.b)),'缺少的分頁會自動建立');ok(!seen.some(x=>x.m==='GET'&&/values\//.test(x.u)),'只寫不讀（不會寫回看板）');
  ok(!JSON.stringify(r.j.settings).includes('rtok')&&!JSON.stringify(r.j.settings).includes('csec'),'回傳的設定遮罩密鑰');
  r=await post('api/admin/integrations',{sheets:{enabled:false},notify:{enabled:true,smtpHost:'127.0.0.1',smtpPort:'9925',smtpSsl:false,from:'board@example.com',rules:[{events:[],projects:['*'],groups:[],emails:['alice@example.com']}]},test:'notify'});
  await W(1500);ok(r.s===200&&mails.length>=1&&/GuGuBoard/.test(mails.join(''))&&/alice@example\.com/i.test(mails.join('')+JSON.stringify(r.j.test)),'SMTP 通知寄出 '+JSON.stringify(r.j&&r.j.test));
  await post('api/admin/integrations',{notify:{enabled:false}});
  await b.close();api.close();smtp.close();console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);})().catch(e=>{console.error(e);process.exit(1);});
