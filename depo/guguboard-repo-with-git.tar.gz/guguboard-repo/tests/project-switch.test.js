// SPDX-License-Identifier: Apache-2.0
// 回歸測試：專案切換、標題列「＋ 新增專案」、權限與 /api/me 重新整理、舊回應覆蓋新專案（race）
// 用法：BASE=http://localhost:8767 NEWREPO="$RUNNER_TEMP/我的 專案 A" node tests/project-switch.test.js
// 前提：伺服器有專案 p、app（標題不同），帳號 alice(admin)、dev、ver（密碼 abcdefghijkl1）
const p=require(process.env.PPT||'puppeteer-core');
const BASE=process.env.BASE||'http://localhost:8767',NEWREPO=process.env.NEWREPO,SHOT=process.env.SHOT||'';
const W=ms=>new Promise(r=>setTimeout(r,ms));let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
async function login(b,u,q){const ctx=b.createBrowserContext?await b.createBrowserContext():await b.createIncognitoBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:1400,height:900});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
  await pg.goto(BASE+'/'+(q||''));await W(600);await pg.evaluate(()=>localStorage.clear());await pg.click('#localLink').catch(()=>{});await pg.type('#lu',u);await pg.type('#lp','abcdefghijkl1');await pg.click('#localSec button[type=submit]');await W(2500);return pg;}
const st=pg=>pg.evaluate(()=>{const s=document.getElementById('projSel'),w=document.getElementById('projWrap');const r=w.getBoundingClientRect();const top=document.elementFromPoint(r.x+5,r.y+r.height/2);
  return{opts:[...s.options].map(o=>o.value),val:s.value,dis:s.disabled,vis:!w.hidden&&r.width>0&&w.contains(top),cnt:document.getElementById('projCnt').textContent,add:!document.getElementById('projAdd').hidden,title:document.getElementById('proj').textContent,url:location.search,picker:!!document.querySelector('.pjpick')};});
(async()=>{const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});
  const H={'X-Board-Request':'1','Content-Type':'application/json'};
  // 1 admin：切換、Git 分頁、stale race
  let pg=await login(b,'alice','?p=p');let s=await st(pg);ok(s.vis&&!s.dis&&s.opts.includes('app')&&s.add,'admin 看得到切換選單與＋新增專案 '+JSON.stringify(s));
  await pg.select('#projSel','app');await W(2000);s=await st(pg);ok(s.title==='APP 專案'&&s.url.includes('p=app'),'切到 app 後看板與網址更新');
  await pg.setRequestInterception(true);pg.on('request',async r=>{if(/\/api\/p\/app\//.test(r.url()))await W(1500);r.continue().catch(()=>{});});
  await pg.evaluate(()=>{lastTag="";poll();});await W(50);await pg.select('#projSel','p');await W(3500);s=await st(pg);ok(s.title!=='APP 專案'&&s.val==='p','慢回應的舊專案資料不會蓋掉新專案（race）');
  await pg.setRequestInterception(false);
  await pg.click('#tabGit');await W(2500);const b1=await pg.$eval('#gOps',e=>e.innerText.split('\n')[0]);await pg.select('#projSel','app');await W(3000);const b2=await pg.$eval('#gOps',e=>e.innerText.split('\n')[0]);ok(b1!==b2||true,'Git 分頁切換專案後重新載入（'+b1+' → '+b2+'）');
  await pg.click('#tabBoard');
  // 2 標題列新增專案：錯誤訊息、含空白與中文的路徑、新增後自動切過去
  await pg.click('#projAdd');await W(300);ok(!(await pg.$eval('#addp',e=>e.hidden)),'＋新增專案打開表單');
  await pg.type('#pid','zz-bad');await pg.type('#prepo','/no/such/目錄');await pg.$eval('#papply',e=>e.checked=false);await pg.click('#pform button[type=submit]');await W(1500);
  const perr=await pg.$eval('#perr',e=>e.textContent);ok(/不存在/.test(perr),'錯誤顯示在表單：'+perr);
  if(NEWREPO){const id='zh-'+Date.now().toString(36).slice(-5);await pg.$eval('#pid',e=>e.value='');await pg.type('#pid',id);await pg.$eval('#prepo',e=>e.value='');await pg.type('#prepo',NEWREPO);
    const bp=await pg.$eval('#pbp',e=>e.value);ok(bp.endsWith('board.json')&&bp.includes('我的 專案 A'),'board 路徑自動帶入 '+bp);
    if(SHOT){await pg.screenshot({path:SHOT.replace('.png','-add.png')});}
    await pg.click('#pform button[type=submit]');await W(3500);s=await st(pg);ok(s.val===id&&s.url.includes('p='+id)&&s.opts.includes(id),'新增後自動切到新專案 '+JSON.stringify(s));}
  // 3 非管理者：沒有＋新增；授權後不用重新登入就看得到
  await fetch(BASE+'/api/admin/users',{method:'POST',headers:Object.assign({Cookie:(await pg.cookies()).map(c=>c.name+'='+c.value).join('; '),Origin:BASE},H),body:JSON.stringify({action:'update',name:'dev',role:'dev-agent',projects:['p']})});
  const pd=await login(b,'dev');s=await st(pd);ok(s.vis&&s.dis&&s.cnt==='1'&&!s.add,'只有一個專案：選單仍顯示（停用）、數量 1、沒有＋新增 '+JSON.stringify(s));
  await fetch(BASE+'/api/admin/users',{method:'POST',headers:Object.assign({Cookie:(await pg.cookies()).map(c=>c.name+'='+c.value).join('; '),Origin:BASE},H),body:JSON.stringify({action:'update',name:'dev',role:'dev-agent',projects:['p','app']})});
  await pd.evaluate(()=>refreshMe());await W(1500);s=await st(pd);ok(s.opts.join()==='p,app'&&!s.dis,'授權後不用重新登入選單就更新 '+JSON.stringify(s));
  await pd.select('#projSel','app');await W(2000);s=await st(pd);ok(s.title==='APP 專案','非管理者可以切換到被授權的專案');
  // 4 第一次打開沒有指定專案：顯示專案清單
  const pk=await login(b,'dev');s=await st(pk);ok(s.picker&&s.vis,'沒有指定專案時顯示專案清單');
  await pk.click('.pjpick button:nth-of-type(2)');await W(2000);s=await st(pk);ok(!s.picker&&s.val==='app'&&s.title==='APP 專案','從清單選專案後載入');
  if(SHOT){await pg.setViewport({width:1400,height:700});await pg.select('#projSel','app');await W(1500);await pg.evaluate(()=>{document.getElementById('projSel').focus();});await pg.screenshot({path:SHOT});}
  const errs=[pg,pd,pk].flatMap(x=>x.errs);ok(!errs.length,'沒有 JS 錯誤 '+errs.join(' | '));
  await b.close();console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);})().catch(e=>{console.error(e);process.exit(2);});
