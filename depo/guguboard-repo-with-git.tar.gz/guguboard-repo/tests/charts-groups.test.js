// SPDX-License-Identifier: Apache-2.0
// 回歸測試：圖表分頁（甘特圖、燃盡圖）、負責人／群組篩選、帳號與群組管理（停用、重設密碼、群組權限、稽核紀錄）
// 用法：BASE=http://localhost:8767 SHOTDIR=dist node tests/charts-groups.test.js
// 前提：伺服器在 BASE，帳號 alice(admin)、dev（密碼 abcdefghijkl1）
const p=require(process.env.PPT||'puppeteer-core');const cp=require('child_process'),fs=require('fs'),path=require('path'),os=require('os');
const BASE=process.env.BASE||'http://localhost:8767',SHOTDIR=process.env.SHOTDIR||'';
const W=ms=>new Promise(r=>setTimeout(r,ms));let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
const git=(d,...a)=>cp.execFileSync('git',['-C',d,...a],{encoding:'utf8'});
async function login(b,u,pw,q){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:1400,height:900});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'newpassword-123':undefined));
  await pg.goto(BASE+'/'+(q||''));await W(600);await pg.evaluate(()=>localStorage.clear());await pg.click('#localLink').catch(()=>{});await pg.type('#lu',u);await pg.type('#lp',pw||'abcdefghijkl1');await pg.click('#localSec button[type=submit]');await W(2500);return pg;}
const post=(pg,url,body)=>pg.evaluate(async(u,b)=>{const r=await fetch(u,{method:'POST',headers:{'X-Board-Request':'1','Content-Type':'application/json'},body:JSON.stringify(b)});return{s:r.status,j:await r.json().catch(()=>null)};},url,body);
const get=(pg,url)=>pg.evaluate(async u=>{const r=await fetch(u);return{s:r.status,j:await r.json().catch(()=>null)};},url);
(async()=>{const T=Date.now().toString(36).slice(-5);const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});
  const pg=await login(b,'alice',null,'?p=app');
  const repo=path.join(os.tmpdir(),'aipm-t','chart-'+T);fs.mkdirSync(repo,{recursive:true});git(repo,'init','-q');git(repo,'-c','user.name=t','-c','user.email=t@t','commit','-q','--allow-empty','-m','chore: init');
  const pid='ch-'+T;let r=await post(pg,'api/projects',{id:pid,name:'圖表測試',repoPath:repo,withExample:true});ok(r.s===200,'建立含範例的專案 '+r.s);
  // 群組：建立 backend，成員 dev，授權這個專案 verifier
  r=await post(pg,'api/admin/users',{action:'groupCreate',id:'backend',name:'後端組'});ok(r.s===200||(r.j&&r.j.error==='E_GROUP_EXISTS'),'建立群組 '+r.s);
  r=await post(pg,'api/admin/users',{action:'groupSet',id:'backend',members:['dev'],projects:{[pid]:'verifier'}});ok(r.s===200,'設定群組成員與專案角色');
  const du=r.j.users.find(u=>u.name==='dev');ok(du&&du.effective[pid]==='verifier'&&du.groups.includes('backend'),'有效權限＝個人與群組取最高 '+JSON.stringify(du&&du.effective));
  r=await post(pg,'api/admin/users',{action:'groupSet',id:'backend',members:['nobody-x'],projects:{}});ok(r.s===400,'不存在的成員被拒絕');
  r=await post(pg,'api/admin/users',{action:'disable',name:'alice'});ok(r.s===409,'不能停用自己');
  await pg.goto(BASE+'/?p='+pid);await W(2500);
  // 甘特圖
  await pg.click('#tabChart');await W(1200);let g=await pg.evaluate(()=>({rows:document.querySelectorAll('svg.gantt .grow').length,bars:document.querySelectorAll('svg.gantt .gbar').length,deps:document.querySelectorAll('svg.gantt .gdep').length,today:!!document.querySelector('svg.gantt .gtoday'),w:document.querySelector('svg.gantt').getAttribute('width')}));
  ok(g.rows===14&&g.bars>=10&&g.deps>=4&&g.today,'甘特圖：14 列、長條、相依箭頭、今天線 '+JSON.stringify(g));
  await pg.click('#gZoom [data-z=day]');await W(400);const wd=await pg.$eval('svg.gantt',e=>+e.getAttribute('width'));await pg.click('#gZoom [data-z=month]');await W(400);const wm=await pg.$eval('svg.gantt',e=>+e.getAttribute('width'));ok(wd>wm*3,'縮放 日／月 改變寬度 '+wd+'/'+wm);
  await pg.click('#gZoom [data-z=week]');await W(300);
  await pg.evaluate(()=>{const t=document.querySelector('svg.gantt [data-tog="E-1"]');t.dispatchEvent(new MouseEvent('click',{bubbles:true}));});await W(400);const rc=await pg.$$eval('svg.gantt .grow',e=>e.length);ok(rc===14-10,'收合 E-1 只剩 E-1 與無父項的佈署 '+rc);
  await pg.evaluate(()=>{const t=document.querySelector('svg.gantt [data-tog="E-1"]');t.dispatchEvent(new MouseEvent('click',{bubbles:true}));});await W(400);
  await pg.evaluate(()=>{document.querySelector('svg.gantt .grow[data-id="T-2"] .gbar').dispatchEvent(new MouseEvent('click',{bubbles:true}));});await W(500);
  const ins=await pg.evaluate(()=>({open:!document.getElementById('insp').hidden,txt:document.getElementById('insp').innerText}));ok(ins.open&&/T-2/.test(ins.txt)&&/相依/.test(ins.txt)&&/@dev/.test(ins.txt),'點長條開啟詳情（含相依、負責）');
  await pg.evaluate(()=>closeInsp());await W(300);
  await pg.click('#sum .pill[data-light=Red]');await W(400);const rr=await pg.$$eval('svg.gantt .grow',e=>e.length);await pg.click('#sum .pill[data-light=Red]');await W(300);ok(rr<14,'燈號篩選套用到甘特圖 '+rr);
  await pg.select('#fAsg','g:backend');await W(500);const ga=await pg.$$eval('svg.gantt .grow:not([opacity="0.45"])',e=>e.map(x=>x.dataset.id));ok(ga.sort().join()==='T-2,T-4,T-5','負責人篩選（群組＝指派給群組或其成員）'+ga.join());
  await pg.select('#fAsg','u:dev');await W(500);const ua=await pg.$$eval('svg.gantt .grow:not([opacity="0.45"])',e=>e.map(x=>x.dataset.id).sort());ok(ua.join()==='T-2,T-4,T-5','選使用者也包含他所屬群組的工單 '+ua.join());
  await pg.select('#fAsg','');await W(400);
  if(SHOTDIR){await pg.click('#gZoom [data-z=day]');await W(400);await pg.screenshot({path:path.join(SHOTDIR,'board-gantt-screenshot.png')});await pg.click('#gZoom [data-z=week]');}
  // 燃盡圖
  await pg.click('#csub [data-v=burn]');await W(800);await pg.select('#bSprint','S1');await W(500);
  let bd=await pg.evaluate(()=>({n:document.querySelectorAll('svg.bchart').length,sum:document.querySelector('.bsum').innerText.replace(/\s+/g,' '),ideal:!!document.querySelector('.bideal'),rem:!!document.querySelector('.brem'),scope:!!document.querySelector('.bscope')}));
  ok(bd.n===2&&bd.ideal&&bd.rem&&bd.scope&&/範圍 5 SP/.test(bd.sum),'燃盡圖（S1、SP）：剩餘線、理想線、燃起圖 '+bd.sum);
  await pg.select('#bUnit','hours');await W(500);bd=await pg.evaluate(()=>document.querySelector('.bsum').innerText.replace(/\s+/g,' '));ok(/範圍 17 h/.test(bd)&&/已完成 6 h/.test(bd),'工時（Task）：S1 範圍 17h、完成 6h（T-1 依 history 轉 Done） '+bd);
  await pg.select('#bSprint','__range');await W(400);await pg.$eval('#bFrom',e=>e.value='2026-10-20');await pg.$eval('#bTo',e=>{e.value='2026-11-25';e.dispatchEvent(new Event('change'));});await W(500);bd=await pg.evaluate(()=>document.querySelector('.bsum').innerText.replace(/\s+/g,' '));ok(/範圍 32 h/.test(bd),'自訂期間計算全部 Task '+bd);
  await pg.select('#bSprint','S1');await W(300);if(SHOTDIR)await pg.screenshot({path:path.join(SHOTDIR,'board-burndown-screenshot.png')});
  // 手機
  const mp=await login(b,'alice',null,'?p='+pid);await mp.setViewport({width:390,height:800,isMobile:true});await mp.click('#tabChart');await W(1000);const mw=await mp.evaluate(()=>({sw:document.documentElement.scrollWidth,g:!!document.querySelector('svg.gantt')}));ok(mw.g&&mw.sw<=420,'手機版：甘特圖在可捲動容器內，頁面不橫向溢出 '+mw.sw);
  // 帳號管理 UI
  await pg.click('#tabBoard');await pg.click('#admBtn');await W(1500);
  const au=await pg.evaluate(()=>({rows:document.querySelectorAll('#admUsers tr[data-name]').length,g:document.querySelectorAll('.gcard').length,audit:document.querySelectorAll('#admAudit tr').length,hdr:document.querySelector('#admUsers').innerText.slice(0,60)}));
  ok(au.rows>=3&&au.g>=1&&au.audit>=2&&/最後登入/.test(au.hdr),'帳號列表含狀態、最後登入、群組；群組卡；稽核紀錄 '+JSON.stringify(au));
  await pg.type('#admQ','backend');await W(200);const vis=await pg.$$eval('#admUsers tr[data-name]',e=>e.filter(x=>!x.hidden).map(x=>x.dataset.name));ok(vis.join()==='dev','搜尋（依群組）'+vis.join());
  await pg.evaluate(()=>{document.querySelector('#admUsers tr[data-name="ver"] .utog').click();});await W(1500);
  const vl=await b.createBrowserContext().then(c=>c.newPage());await vl.goto(BASE+'/');await W(500);const lr=await post(vl,'api/login',{username:'ver',password:'abcdefghijkl1'});ok(lr.s===403&&lr.j.error==='E_DISABLED','停用後無法登入 '+lr.s);
  await pg.evaluate(()=>{document.querySelector('#admUsers tr[data-name="ver"] .utog').click();});await W(1500);const lr2=await post(vl,'api/login',{username:'ver',password:'abcdefghijkl1'});ok(lr2.s===200,'重新啟用後可登入');
  await pg.evaluate(()=>{document.querySelector('#admUsers tr[data-name="view"] .urp').click();});await W(2000);const lr3=await post(vl,'api/login',{username:'view',password:'newpassword-123'});ok(lr3.s===200,'本機重設密碼');
  await post(pg,'api/admin/users',{action:'resetPassword',name:'view',password:'abcdefghijkl1'});
  if(SHOTDIR){await pg.$eval('#admQ',e=>{e.value='';e.oninput();});await pg.evaluate(()=>document.querySelector('.gcard').scrollIntoView());await W(300);await pg.screenshot({path:path.join(SHOTDIR,'board-groups-screenshot.png')});}
  const aud=(await get(pg,'api/admin/users')).j.audit.map(a=>a.action);ok(['groupCreate','groupSet','disable','enable','resetPassword'].every(a=>aud.includes(a))&&!JSON.stringify((await get(pg,'api/admin/users')).j.audit).includes('newpassword'),'稽核紀錄有群組／停用／重設，且不含密碼');
  // dev 透過群組看得到專案（verifier）；刪除群組後權限消失
  const pd=await login(b,'dev',null,'?p='+pid);const me=(await get(pd,'api/me')).j||{};if(!me.projects)console.log('me=',JSON.stringify(me));me.projects=me.projects||[];ok(me.projects.some(x=>x.id===pid&&x.role==='verifier'),'dev 透過群組取得 verifier');
  const pe=(await get(pd,'api/p/'+pid+'/people')).j;ok(pe.groups.some(g=>g.id==='backend')&&pe.users.includes('dev'),'people API 列出可指派的人與群組');
  await post(pg,'api/admin/users',{action:'groupDelete',id:'backend'});const me2=(await get(pd,'api/me')).j;ok(!me2.projects.some(x=>x.id===pid),'刪除群組後權限立即失效');
  r=await post(pd,'api/admin/users',{action:'groupCreate',id:'x',name:'x'});ok(r.s===403,'非管理者不能管理群組');
  const errs=[pg,pd,mp].flatMap(x=>x.errs);ok(!errs.length,'沒有 JS 錯誤 '+errs.join(' | '));
  await b.close();console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);})().catch(e=>{console.error(e);process.exit(2);});
