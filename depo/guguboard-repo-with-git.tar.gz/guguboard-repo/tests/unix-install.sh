#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# Linux／macOS 安裝冒煙測試：install.sh 裝到暫時 HOME → guguboard start → 看板 200 → apply 到暫時 repo → 升級產生 .bak → uninstall
# 用法：sh tests/unix-install.sh [dist 資料夾]   （需要 pwsh、git、curl；不會使用 sudo）
set -eu
DIST=$(cd "${1:-dist}" && pwd)
case $(uname -s) in Darwin) PKG=GuGuBoard-macOS; INST=Applications/GuGuBoard ;; *) PKG=GuGuBoard-Linux; INST=.local/share/gugu-board ;; esac
T=$(mktemp -d); export HOME="$T/home"; mkdir -p "$HOME"; export PATH="$PATH:$HOME/.local/bin"
export GUGUBOARD_PORT=${GUGUBOARD_PORT:-8791} GUGUBOARD_NO_BROWSER=1
fail() { echo "FAIL $*"; cat "$T"/*.log 2>/dev/null | tail -40; exit 1; }
ok() { echo "PASS $*"; }
cd "$T"; tar -xzf "$DIST/$PKG.tar.gz"
sh "$PKG/install.sh" --no-open >inst.log 2>&1 || fail "install.sh"; ok "install.sh"
G="$HOME/$INST/guguboard"; [ -x "$G" ] || fail "launcher 不可執行"
[ "$("$G" version)" = "$(cat "$HOME/$INST/VERSION")" ] && ok "version"
if [ "$PKG" = GuGuBoard-Linux ]; then [ -L "$HOME/.local/bin/guguboard" ] && [ -f "$HOME/.local/share/applications/guguboard.desktop" ] || fail "launcher／desktop"; ok "~/.local/bin 與 .desktop"
else [ -x "$HOME/Applications/GuGuBoard.app/Contents/MacOS/GuGuBoard" ] && [ -f "$HOME/Applications/GuGuBoard.app/Contents/Resources/gugu.icns" ] || fail "GuGuBoard.app"; plutil -lint "$HOME/Applications/GuGuBoard.app/Contents/Info.plist" >/dev/null || fail plist; ok "GuGuBoard.app"; fi
"$G" start >start.log 2>&1 || fail "start"
code=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:$GUGUBOARD_PORT/"); [ "$code" = 200 ] || fail "看板 $code"; ok "看板 200"
mkdir r; git -C r init -q; git -C r -c user.name=t -c user.email=t@example.invalid commit -q --allow-empty -m init
"$G" apply "$T/r" >apply.log 2>&1 || fail "apply"; ok "apply"
grep -q '"pwsh' r/.cursor/hooks.json && ! grep -q powershell r/.cursor/hooks.json || fail "hooks.json 未改成 pwsh"; ok "hooks.json 用 pwsh"
[ -x r/.githooks/pre-commit ] && [ -x r/.githooks/commit-msg ] && [ -x r/.ai-hooks/ai-hook.sh ] || fail "hooks 不可執行"; ok "hooks 可執行"
[ "$(git -C r config core.hooksPath)" = .githooks ] || fail "core.hooksPath"; ok "core.hooksPath"
m=$(ls -ld "$HOME/$INST/.ai-board" | cut -c1-10); [ "$m" = drwx------ ] || fail ".ai-board 權限 $m"; ok ".ai-board 700"
"$G" stop >/dev/null 2>&1 || true
echo "# local edit" >> "$HOME/$INST/serve-board.ps1"
sh "$PKG/install.sh" --no-open >up.log 2>&1 || fail "升級"; [ -f "$HOME/$INST/serve-board.ps1.bak" ] || fail "沒有 .bak"; ok "升級保留 .bak"
sh "$PKG/uninstall.sh" >un.log 2>&1 || fail "uninstall"; [ ! -e "$HOME/$INST/guguboard" ] || fail "uninstall 沒刪檔"; ok "uninstall"
if [ -f "$DIST"/guguboard_*_all.deb ] && command -v dpkg >/dev/null 2>&1; then
  D="$T/deb"; dpkg -x "$DIST"/guguboard_*_all.deb "$D"; chmod -R a-w "$D/opt/guguboard"
  GUGUBOARD_PORT=$((GUGUBOARD_PORT+1)) "$D/opt/guguboard/guguboard" start >deb.log 2>&1 || fail "deb start"
  code=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:$((GUGUBOARD_PORT+1))/"); [ "$code" = 200 ] || fail "deb 看板 $code"
  [ -f "$HOME/.config/guguboard/server.pid" ] || fail "deb 設定不在 ~/.config/guguboard"; ok ".deb（dpkg -x）看板 200，設定在 ~/.config/guguboard"
  GUGUBOARD_PORT=$((GUGUBOARD_PORT+1)) "$D/opt/guguboard/guguboard" stop >/dev/null 2>&1 || true; chmod -R u+w "$D"
fi
rm -rf "$T"; echo "全部通過"
