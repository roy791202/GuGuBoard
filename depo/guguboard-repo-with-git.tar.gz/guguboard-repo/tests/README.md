# 測試 Tests

從 repo 根目錄執行。Run from the repo root.

| 測試 | 指令 | 需要 |
|---|---|---|
| PowerShell 語法＋5.1 相容 | `pwsh tests/parse-check.ps1` | pwsh |
| macOS／Linux 安裝冒煙測試 | `python3 scripts/build.py --no-windows && sh tests/unix-install.sh dist` | pwsh、git、curl（.deb 部分需要 dpkg） |
| PowerShell 安裝冒煙測試 | `python3 scripts/build.py && pwsh tests/windows-install.ps1` | pwsh 或 Windows PowerShell 5.1、git |
| 看板端對端 | `python3 scripts/build_payload.py && eval "$(sh tests/e2e-setup.sh)" && node tests/rules-layers.test.js` | Node 20、`npm i --no-save puppeteer-core`、Chrome（`CHROME=` 指定路徑） |

端對端測試檔：`rules-layers`、`empty-project`、`charts-groups`、`aipm-features`（CI 會跑）；`project-switch`（需要 `NEWREPO`）、`google-mocks`（需要本機 mock 埠 9911／9925）可手動執行。
`e2e-setup.sh` 建立的測試帳號密碼只存在暫時資料夾，與任何真實帳號無關。

MCP 測試：`mcp.test.py` 用官方 Python MCP SDK（`pip install "mcp>=1.10,<2"`）實際連線，HTTP 與 stdio 橋接都測（握手、tools/list、工具呼叫、規則拒絕、token 認證、稽核、`guguboard mcp install`）；`mcp-settings.test.js` 測設定頁（三種語言、四種主題）。
