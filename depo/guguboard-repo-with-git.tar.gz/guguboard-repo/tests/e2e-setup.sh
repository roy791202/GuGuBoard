#!/bin/sh
# SPDX-License-Identifier: Apache-2.0
# 端對端測試環境：從 build/payload/core 建一個暫時的 GuGuBoard，建立測試帳號與專案，啟動伺服器
# 用法：eval "$(sh tests/e2e-setup.sh)"   → 輸出 export AIPM=… BASE=… CFG=…
# 測試帳號：alice(admin)、dev(dev-agent)、ver(verifier)、view(viewer)；密碼固定為測試用 abcdefghijkl1（只存在暫時資料夾）
set -eu
ROOT=$(cd "$(dirname "$0")/.." && pwd); PWSH=${PWSH:-pwsh}; PORT=${PORT:-8767}
W=${E2E_DIR:-$(mktemp -d)}; AIPM="$W/AI_PM"; mkdir -p "$AIPM"
cp -R "$ROOT/build/payload/core/." "$AIPM/"
cd "$AIPM"
for id in p app; do
  R="$W/repo-$id"; mkdir -p "$R/docs"; git -C "$R" init -q
  cp "$AIPM/board.example.json" "$R/docs/board.json"
  git -C "$R" add -A; git -C "$R" -c user.name=t -c user.email=t@example.invalid commit -q -m init
  "$PWSH" -NoProfile -File serve-board.ps1 -AddProject "$id" -Name "Project $id" -BoardPath "$R/docs/board.json" -GitRepo "$R" >&2
done
adduser() { "$PWSH" -NoProfile -Command "& ./serve-board.ps1 -AddUser $1 -Role $2 $3 -Password (ConvertTo-SecureString 'abcdefghijkl1' -AsPlainText -Force)" >&2; }
adduser alice admin ''; adduser dev dev-agent '-Project p,app'; adduser ver verifier '-Project p'; adduser view viewer '-Project p'
(AIPM_LEASE_MIN=0.25 nohup "$PWSH" -NoProfile -File serve-board.ps1 -NoOpen -Port "$PORT" >"$W/server.log" 2>&1 &)
i=0; until curl -fs "http://localhost:$PORT/api/status" >/dev/null 2>&1; do i=$((i+1)); [ $i -gt 60 ] && { cat "$W/server.log" >&2; exit 1; }; sleep 1; done
echo "export AIPM='$AIPM' CFG='$AIPM/.ai-board' BASE='http://localhost:$PORT' E2E_DIR='$W' PWSH='$PWSH'"
