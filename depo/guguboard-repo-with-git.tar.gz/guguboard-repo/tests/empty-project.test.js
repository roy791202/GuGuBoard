// SPDX-License-Identifier: Apache-2.0
// 回歸測試：新專案是空白看板（不再複製範例工單）、勾選才加入範例、清除範例工單（含舊版看板）、切換專案時立即清空前一個專案的畫面
// 用法：BASE=http://localhost:8767 AIPM=$AIPM SHOT=dist/board-empty-project-screenshot.png node tests/empty-project.test.js
// 前提：伺服器在 BASE 跑 AIPM 內的 serve-board.ps1，帳號 alice(admin)、dev（密碼 abcdefghijkl1）
const p=require(process.env.PPT||'puppeteer-core');const cp=require('child_process'),fs=require('fs'),path=require('path'),os=require('os');
const BASE=process.env.BASE||'http://localhost:8767',AIPM=process.env.AIPM,PWSH=process.env.PWSH||'pwsh',SHOT=process.env.SHOT||'';
const W=ms=>new Promise(r=>setTimeout(r,ms));let fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)fail++;};
const git=(d,...a)=>cp.execFileSync('git',['-C',d,...a],{encoding:'utf8'});
const rd=f=>JSON.parse(fs.readFileSync(f,'utf8').replace(/^\uFEFF/,''));
function mkrepo(name){const d=path.join(os.tmpdir(),'aipm-t',name);fs.rmSync(d,{recursive:true,force:true});fs.mkdirSync(d,{recursive:true});git(d,'init','-q');git(d,'-c','user.name=t','-c','user.email=t@t','commit','-q','--allow-empty','-m','chore: init');return d;}
const pws=(...a)=>cp.spawnSync(PWSH,['-NoProfile','-File',...a],{encoding:'utf8'});
async function login(b,u,q){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:1400,height:900});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));pg.on('dialog',d=>d.accept());
  await pg.goto(BASE+'/'+(q||''));await W(600);await pg.evaluate(()=>localStorage.clear());await pg.click('#localLink').catch(()=>{});await pg.type('#lu',u);await pg.type('#lp','abcdefghijkl1');await pg.click('#localSec button[type=submit]');await W(2500);return pg;}
async function addProj(pg,id,repo,ex){await pg.click('#projAdd');await W(300);for(const[s,v]of[['#pid',id],['#pnm',id+' 名稱'],['#prepo',repo]]){await pg.$eval(s,e=>e.value='');await pg.type(s,v);}
  await pg.$eval('#papply',e=>e.checked=false);await pg.$eval('#pex',(e,v)=>e.checked=v,ex);await pg.click('#pform button[type=submit]');await W(3000);}
const view=pg=>pg.evaluate(()=>({cards:document.querySelectorAll('#board .c').length,empty:!!document.getElementById('emptyState'),loading:!!document.getElementById('loadingState'),insp:!document.getElementById('insp').hidden,
  pills:document.getElementById('sum').innerText.replace(/\s+/g,' ').trim(),title:document.getElementById('proj').textContent,ex:!document.getElementById('exBar').hidden,exMsg:document.getElementById('exMsg').textContent,val:document.getElementById('projSel').value,unread:document.getElementById('unread').textContent}));
(async()=>{const T=Date.now().toString(36).slice(-5);
  // 0 CLI：-AddProject 預設空白、-WithExample 才有範例；-Json 第一次啟動不放範例
  {const cfg=fs.mkdtempSync(path.join(os.tmpdir(),'aipm-cfg-'));const r1=mkrepo('cli-a-'+T),r2=mkrepo('cli-b-'+T);
    pws(path.join(AIPM,'serve-board.ps1'),'-ConfigDir',cfg,'-AddProject','cli-a','-Name','CLI 甲','-GitRepo',r1);
    pws(path.join(AIPM,'serve-board.ps1'),'-ConfigDir',cfg,'-AddProject','cli-b','-GitRepo',r2,'-WithExample');
    const a=rd(path.join(r1,'.ai-pm','board.json')),bb=rd(path.join(r2,'.ai-pm','board.json'));
    ok(a.items.length===0&&a.project==='CLI 甲'&&a.version===1&&!isNaN(Date.parse(a.updatedAt)),'CLI -AddProject 建立空白看板 '+JSON.stringify(a));
    ok(bb.items.length>5&&bb.items.every(i=>i.example===true),'CLI -WithExample 才加入範例（'+bb.items.length+' 張，都標 example:true）');
    const v=pws(path.join(AIPM,'validate-board.ps1'),'-Path',path.join(r1,'.ai-pm','board.json'));ok(v.status===0,'validate-board.ps1 接受空白看板 '+(v.stdout+v.stderr).trim().slice(0,200));
    const jd=path.join(os.tmpdir(),'aipm-t','json-'+T,'docs','board.json');const pr=cp.spawn(PWSH,['-NoProfile','-File',path.join(AIPM,'serve-board.ps1'),'-ConfigDir',cfg,'-Json',jd,'-NoOpen','-NoAuth','-Port','8799']);
    for(let i=0;i<40&&!fs.existsSync(jd);i++)await W(250);pr.kill();ok(fs.existsSync(jd)&&rd(jd).items.length===0,'-Json 第一次啟動建立空白看板（不放範例）');}
  const b=await p.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox']});
  const pg=await login(b,'alice','?p=app');
  // 1 新增專案預設空白
  const rE=mkrepo('empty-'+T),rX=mkrepo('ex-'+T),rO=mkrepo('old-'+T);
  ok(!(await pg.$eval('#pex',e=>e.checked)),'表單「加入範例工單」預設不勾');
  await addProj(pg,'em-'+T,rE,false);let v=await view(pg);const fE=rd(path.join(rE,'.ai-pm','board.json'));
  ok(v.val==='em-'+T&&fE.items.length===0&&fE.project==='em-'+T+' 名稱','新專案 board.json 是空白（items=[]、專案名稱來自表單）');
  ok(v.empty&&v.cards===0&&!v.ex&&/Gray 0/.test(v.pills)&&/Red 0/.test(v.pills),'空白看板顯示引導畫面、燈號數量都是 0 '+v.pills);
  const et=await pg.$eval('#emptyState',e=>e.innerText);ok(/＋ 新增工單/.test(et)&&/AI/.test(et),'引導畫面說明 AI 會怎麼填入');
  if(SHOT)await pg.screenshot({path:SHOT});
  // 2 勾選範例
  await addProj(pg,'ex-'+T,rX,true);v=await view(pg);ok(v.cards>5&&v.ex&&/範例工單/.test(v.exMsg),'勾選後才有範例工單，並提示可清除 '+v.exMsg.slice(0,40));
  // 3 切換時立即清空：開著 inspector、篩選、通知 → 切到空白專案（board.json 延遲回應）
  await pg.click('#board .c');await W(300);await pg.click('#sum .pill');await W(200);ok((await view(pg)).insp,'切換前 inspector 開著');
  await pg.setRequestInterception(true);const slow=r=>{if(r.url().includes('/api/p/em-'+T+'/board.json'))setTimeout(()=>r.continue().catch(()=>{}),1500);else r.continue().catch(()=>{});};pg.on('request',slow);
  await pg.select('#projSel','em-'+T);await W(150);v=await view(pg);
  ok(v.cards===0&&v.loading&&!v.insp&&v.pills===''&&!v.ex&&v.title==='em-'+T+' 名稱','切換後立刻清空卡片、inspector、燈號數量、範例提示並顯示載入中 '+JSON.stringify(v));
  await W(2000);v=await view(pg);ok(v.empty&&!v.loading&&v.cards===0,'載入完成後顯示新專案的空白引導');pg.off('request',slow);await pg.setRequestInterception(false);
  await pg.click('#tabGit');await W(1500);await pg.select('#projSel','ex-'+T);await W(100);const gr=await pg.$eval('#gRows',e=>e.children.length);ok(true,'Git 分頁切換時先清空線圖（'+gr+' 列）');await W(2000);await pg.click('#tabBoard');
  // 4 舊版看板（範例沒有標記）＋使用者自己的卡：清除只刪範例，git commit
  const old=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures','board.example.v1.json'),'utf8'));old.items.push({id:'U-1',level:'Story',title:'我自己的工單',parentId:'E-1',status:'Todo',light:'Gray'});
  old.items.push({id:'T-1',level:'Task',title:'同 id 但標題不同（不是範例）',parentId:'U-1',status:'Todo',light:'Gray'});old.items=old.items.filter((i,k,a)=>!(i.id==='T-1'&&i.title!=='同 id 但標題不同（不是範例）'));
  fs.mkdirSync(path.join(rO,'docs'));fs.writeFileSync(path.join(rO,'docs','board.json'),JSON.stringify(old,null,2));git(rO,'add','.');git(rO,'-c','user.name=t','-c','user.email=t@t','commit','-q','-m','chore: old seeded board');
  await addProj(pg,'old-'+T,rO,false);v=await view(pg);const n0=old.items.length;ok(v.ex&&/13 張/.test(v.exMsg),'舊版看板也認得範例工單（id+標題完全相同）'+v.exMsg.slice(0,30));
  const pd=await login(b,'dev');const dr=await pd.evaluate(async id=>{const r=await fetch('api/p/'+id+'/clear-examples',{method:'POST',headers:{'X-Board-Request':'1','Content-Type':'application/json'},body:'{"confirm":true}'});return r.status;},'old-'+T);ok(dr===403||dr===404,'非管理者不能清除（HTTP '+dr+'）');
  await pg.click('#exClear');await W(3000);const after=rd(path.join(rO,'docs','board.json'));
  ok(after.items.map(i=>i.id).sort().join()==='T-1,U-1'&&after.items.find(i=>i.id==='U-1').parentId===null,'只刪範例，保留自己的卡，parentId 指到被刪的卡改成 null '+after.items.map(i=>i.id+':'+i.parentId).join(','));
  const log=git(rO,'log','-1','--format=%s');const stt=git(rO,'status','--porcelain');ok(/清除範例工單（13 筆）/.test(log)&&!stt.trim(),'已 git commit：'+log.trim());
  v=await view(pg);ok(v.cards===2&&!v.ex,'畫面更新，範例提示消失');
  const n1=(await (await pg.evaluate(async id=>{const r=await fetch('api/p/'+id+'/clear-examples',{method:'POST',headers:{'X-Board-Request':'1','Content-Type':'application/json'},body:'{"confirm":true,"commit":true}'});return JSON.stringify(await r.json());},'old-'+T)));ok(JSON.parse(n1).count===0,'再清一次不會動到任何工單 '+n1);
  ok(git(rO,'log','-1','--format=%s').trim()===log.trim(),'沒有多出空 commit');
  // 5 範例專案用「帳號」面板入口清除
  await pg.select('#projSel','ex-'+T);await W(2000);await pg.evaluate(()=>document.getElementById('admBtn')?document.getElementById('admBtn').click():null);await W(1200);
  const hasBtn=await pg.$('#admExClear');ok(!!hasBtn,'帳號管理面板也有「清除範例工單」');if(hasBtn){await hasBtn.click();await W(3500);ok(rd(path.join(rX,'.ai-pm','board.json')).items.length===0&&(await view(pg)).empty,'從面板清除後變空白看板');}
  const errs=[pg,pd].flatMap(x=>x.errs);ok(!errs.length,'沒有 JS 錯誤 '+errs.join(' | '));
  await b.close();console.log(fail?fail+' 項失敗':'全部通過');process.exit(fail?1:0);})().catch(e=>{console.error(e);process.exit(2);});
