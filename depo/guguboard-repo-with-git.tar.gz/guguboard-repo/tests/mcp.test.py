# SPDX-License-Identifier: Apache-2.0
# MCP 端對端測試：用官方 Python MCP SDK（真正的 MCP 用戶端）連 GuGuBoard
#   HTTP（POST /mcp）與 stdio 橋接（mcp-stdio.ps1）都測：握手、tools/list、工具呼叫、規則拒絕、token 認證、稽核、guguboard mcp install
# 用法：pip install "mcp>=1.10,<2"；eval "$(sh tests/e2e-setup.sh)"；python3 tests/mcp.test.py
import asyncio, json, os, subprocess, sys, tempfile, urllib.request, urllib.error, http.cookiejar
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamablehttp_client

BASE = os.environ.get('BASE', 'http://localhost:8767'); AIPM = os.environ['AIPM']; CFG = os.environ.get('CFG', os.path.join(AIPM, '.ai-board'))
PWSH = os.environ.get('PWSH', 'pwsh'); E2E = os.environ.get('E2E_DIR', tempfile.mkdtemp())
fails = 0
def ok(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1

jar = http.cookiejar.CookieJar(); op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def call(path, body=None, headers=None, method=None):
    h = {'Content-Type': 'application/json', 'X-Board-Request': '1'}; h.update(headers or {})
    rq = urllib.request.Request(BASE + path, data=None if body is None else json.dumps(body).encode(), headers=h, method=method or ('POST' if body is not None else 'GET'))
    try:
        r = op.open(rq); t = r.read().decode(); return r.status, (json.loads(t) if t else None), r.headers
    except urllib.error.HTTPError as e:
        t = e.read().decode(); return e.code, (json.loads(t) if t.startswith('{') else t), e.headers
def rpc(tok, msg, headers=None):
    h = {'Authorization': 'Bearer ' + tok} if tok else {}; h.update(headers or {})
    return call('/mcp', msg, h)
def text(r): return '\n'.join(c.text for c in r.content if getattr(c, 'type', '') == 'text')

# ---- 準備：管理者登入、關掉再打開 MCP、建立 token ----
call('/api/login', {'username': 'alice', 'password': 'abcdefghijkl1'})
call('/api/admin/integrations', {'mcp': {'enabled': False}})
s, j, _ = rpc('x', {'jsonrpc': '2.0', 'id': 1, 'method': 'ping'}); ok(s == 404 and j['error'] == 'E_MCP_DISABLED', 'MCP 預設關閉時回 404 E_MCP_DISABLED')
call('/api/admin/integrations', {'mcp': {'enabled': True, 'allowExternal': False}})
s, dev, _ = call('/api/p/p/agent-tokens', {'action': 'create', 'role': 'dev-agent', 'name': 'mcp-dev', 'days': 1}); ok(s == 200 and dev['token'].startswith('aipm_'), '設定頁可建立 dev-agent token')
_, ver, _ = call('/api/p/p/agent-tokens', {'action': 'create', 'role': 'verifier', 'name': 'mcp-ver', 'days': 1})
_, gone, _ = call('/api/p/p/agent-tokens', {'action': 'create', 'role': 'dev-agent', 'name': 'mcp-gone', 'days': 1})
call('/api/p/p/agent-tokens', {'action': 'revoke', 'id': gone['id']})
DEV, VER = dev['token'], ver['token']
# 測試用工單：直接加進專案 p 的 board.json（伺服器每次都從檔案讀）
bp = os.path.join(E2E, 'repo-p', 'docs', 'board.json'); bd = json.load(open(bp, encoding='utf-8'))
story = next(i for i in bd['items'] if i['level'] == 'Story')['id']; now = '2026-11-03T09:00:00+08:00'
bd['items'] = [i for i in bd['items'] if i['id'] != 'MCP-1'] + [{'id': 'MCP-1', 'level': 'Task', 'title': 'MCP 測試工單', 'parentId': story, 'status': 'Todo', 'light': 'Gray', 'createdAt': now, 'updatedAt': now, 'history': []}]
json.dump(bd, open(bp, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

# ---- token 認證與連線限制 ----
ping = {'jsonrpc': '2.0', 'id': 1, 'method': 'ping'}
s, j, h = rpc('', ping); ok(s == 401 and 'Bearer' in (h.get('WWW-Authenticate') or ''), '沒有 token → 401')
s, j, _ = rpc(DEV[:-3] + 'abc', ping); ok(s == 401, '錯誤 token → 401')
s, j, _ = rpc(gone['token'], ping); ok(s == 401, '已撤銷 token → 401')
s, j, _ = rpc(DEV, ping, {'X-Forwarded-For': '1.2.3.4'}); ok(s == 403 and j['error'] == 'E_MCP_LOCAL_ONLY', '外部連線預設擋下（需在設定開啟）')
call('/api/admin/integrations', {'mcp': {'enabled': True, 'allowExternal': True}})
s, j, _ = rpc(DEV, ping, {'X-Forwarded-For': '1.2.3.4'}); ok(s == 200, '勾選允許外部後，經 tunnel 的請求可連（仍需 token）')
s, j, _ = rpc('', ping, {'X-Forwarded-For': '1.2.3.4'}); ok(s == 401, '外部沒有 token 一樣 401')
call('/api/admin/integrations', {'mcp': {'enabled': True, 'allowExternal': False}})
s, j, _ = rpc(DEV, ping, {'Origin': 'http://evil.example'}); ok(s == 403, '陌生 Origin（DNS rebinding）擋下')
s, j, _ = rpc(DEV, {'jsonrpc': '2.0', 'method': 'notifications/initialized'}); ok(s == 202, '通知（沒有 id）回 202')
s, j, _ = rpc(DEV, {'jsonrpc': '2.0', 'id': 9, 'method': 'nope'}); ok(j['error']['code'] == -32601, '未知方法回 -32601')

async def flow(sess: ClientSession, label):
    init = await sess.initialize(); ok(init.serverInfo.name == 'guguboard' and 'L1' in (init.instructions or ''), f'{label} 握手 initialize（{init.protocolVersion}）')
    names = {t.name for t in (await sess.list_tools()).tools}
    want = {'list_projects', 'get_board_summary', 'list_tickets', 'get_ticket', 'claim_ticket', 'renew_lease', 'release_ticket', 'update_ticket_progress', 'add_ticket_note', 'answer_verifier_question', 'submit_for_tdd', 'get_rules', 'list_runs', 'get_run_log'}
    ok(want <= names, f'{label} tools/list 有 {len(names)} 個工具')
    pr = await sess.get_prompt('guguboard_collaborate'); ok('claim_ticket' in pr.messages[0].content.text, f'{label} 協作提示詞（MCP prompt）')
    rr = await sess.read_resource('guguboard://rules'); ok('[L5]' in rr.contents[0].text, f'{label} resources/read guguboard://rules')
    r = await sess.call_tool('list_projects', {}); ok(r.structuredContent['projects'][0]['id'] == 'p', f'{label} list_projects')
    return names

async def http_flow():
    async with streamablehttp_client(BASE + '/mcp', headers={'Authorization': 'Bearer ' + DEV}) as (rd, wr, _):
        async with ClientSession(rd, wr) as sess:
            await flow(sess, 'HTTP')
            r = await sess.call_tool('list_tickets', {'light': 'Yellow'}); ok(not r.isError and all(t['light'] == 'Yellow' for t in r.structuredContent['tickets']), 'list_tickets 依燈號篩選')
            r = await sess.call_tool('get_rules', {}); ok('[L1]' in text(r), 'get_rules 回 L1–L7')
            r = await sess.call_tool('claim_ticket', {'ticket': 'MCP-1'}); tk = r.structuredContent.get('ticket'); ok(not r.isError and tk, f'claim_ticket 領到 {tk}')
            r = await sess.call_tool('renew_lease', {'ticket': tk}); ok(not r.isError, 'renew_lease 延長租約')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'status': 'In Progress', 'light': 'Green', 'reason': '開始實作'}); ok(not r.isError, 'update_ticket_progress → In Progress 綠燈')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'light': 'Yellow', 'reason': '卡住'}); ok(r.isError and '[L4]' in text(r) and 'L4' in r.structuredContent['rules'], '黃燈沒填 lightReason → [L4] 拒絕')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'status': 'Done', 'reason': 'x'}); ok(r.isError and '[L5]' in text(r), 'AI 移到 Done → [L5] 拒絕')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'light': 'Blue', 'reason': 'x'}); ok(r.isError and '[L5]' in text(r), 'AI 設藍燈 → [L5] 拒絕')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'status': 'Todo'}); ok(r.isError and '[L7]' in text(r), '變更沒寫 reason → [L7] 拒絕')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'status': 'Todo', 'light': 'Green', 'reason': 'x'}); ok(r.isError and '[L1]' in text(r), 'Todo 綠燈 → [L1] 拒絕（伺服器驗證器）')
            r = await sess.call_tool('add_ticket_note', {'ticket': tk, 'text': '已寫好失敗測試'}); ok(not r.isError, 'add_ticket_note')
            r = await sess.call_tool('answer_verifier_question', {'ticket': tk, 'question': '為什麼用 lease？', 'answer': '避免兩個代理做同一張'}); ok(not r.isError, 'answer_verifier_question')
            r = await sess.call_tool('submit_for_tdd', {'ticket': tk, 'summary': 'x', 'testsPassed': 3, 'testsFailed': 1}); ok(r.isError and '[L6]' in text(r), '測試沒全綠就送驗 → [L6] 拒絕')
            r = await sess.call_tool('submit_for_tdd', {'ticket': tk, 'summary': '完成，3 個測試通過', 'testsPassed': 3, 'prUrl': 'https://github.com/o/r/pull/1'}); ok(not r.isError, 'submit_for_tdd → In Review ' + (text(r)[:300] if r.isError else ''))
            r = await sess.call_tool('get_ticket', {'ticket': tk}); t = r.structuredContent['ticket']
            ok(t['status'] == 'In Review' and t['light'] == 'Green' and any('READY_FOR_TDD' in n['text'] for n in t['notes']) and t['history'][-1]['by'].startswith('mcp-dev'), 'get_ticket：狀態、READY_FOR_TDD 備註、history 都寫入')
            r = await sess.call_tool('list_runs', {}); ok(not r.isError, 'list_runs')
            r = await sess.call_tool('get_run_log', {'log': '../x.log'}); ok(r.isError, 'get_run_log 擋路徑穿越')
            r = await sess.call_tool('get_ticket', {'ticket': '../../etc'}); ok(r.isError, '工單 id 格式檢查')
            return tk

async def verifier_flow(tk):
    async with streamablehttp_client(BASE + '/mcp', headers={'Authorization': 'Bearer ' + VER}) as (rd, wr, _):
        async with ClientSession(rd, wr) as sess:
            await sess.initialize()
            r = await sess.call_tool('add_ticket_note', {'ticket': tk, 'text': '我來改'}); ok(r.isError and 'E_CLAIMED' in text(r), '別人領取中的工單 → E_CLAIMED 拒絕')
            r = await sess.call_tool('update_ticket_progress', {'ticket': tk, 'status': 'Done', 'reason': '驗證通過'}); ok(r.isError and '[L5]' in text(r), '驗證代理透過 MCP 也不能移到 Done')

async def stdio_flow(env, cwd, label):
    args = ['-NoProfile', '-File', os.path.join(AIPM, 'mcp-stdio.ps1')]
    async with stdio_client(StdioServerParameters(command=PWSH, args=args, env=env, cwd=cwd)) as (rd, wr):
        async with ClientSession(rd, wr) as sess:
            await flow(sess, label)
            r = await sess.call_tool('get_board_summary', {}); ok(not r.isError and r.structuredContent['total'] > 0, f'{label} get_board_summary（中文正常：{r.structuredContent["name"]}）')

tk = asyncio.run(http_flow())
asyncio.run(verifier_flow(tk))
# release 後再看
s, j, _ = rpc(DEV, {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'release_ticket', 'arguments': {'ticket': tk}}}); ok(j['result']['isError'] is False, 'release_ticket')

base_env = {k: v for k, v in os.environ.items() if k not in ('GUGUBOARD_TOKEN', 'GUGUBOARD_URL', 'GUGUBOARD_PROJECT')}
asyncio.run(stdio_flow(dict(base_env, GUGUBOARD_TOKEN=DEV, GUGUBOARD_URL=BASE), E2E, 'stdio(env)'))

# ---- guguboard mcp install：token 存使用者資料夾，repo 設定檔不含 token ----
home = tempfile.mkdtemp(); repo = os.path.join(E2E, 'repo-mcp'); os.makedirs(os.path.join(repo, '.ai-pm', 'x'), exist_ok=True)
json.dump({'aipm': 1, 'id': 'p', 'name': 'P'}, open(os.path.join(repo, '.ai-pm', 'project.json'), 'w'))
env = dict(base_env, HOME=home, USERPROFILE=home, XDG_CONFIG_HOME=os.path.join(home, '.config'))
inst = lambda *a, **k: subprocess.run([PWSH, '-NoProfile', '-File', os.path.join(AIPM, 'guguboard-mcp.ps1'), *a], cwd=k.get('cwd', repo), env=env, capture_output=True, text=True)
p = inst('install', 'cursor', '-Token', DEV, '-Url', BASE); ok(p.returncode == 0, 'mcp install cursor ' + (p.stderr.strip()[:200]))
cur = json.load(open(os.path.join(repo, '.cursor', 'mcp.json'))); ok('guguboard' in cur['mcpServers'] and DEV not in json.dumps(cur), '.cursor/mcp.json 有 guguboard，且不含 token')
st = json.load(open(os.path.join(home, '.guguboard', 'mcp.json'))); ok(st['projects']['p']['token'] == DEV, 'token 存到 ~/.guguboard/mcp.json（依 .ai-pm/project.json 的專案 id）')
ok(oct(os.stat(os.path.join(home, '.guguboard', 'mcp.json')).st_mode & 0o777) == '0o600', 'token 檔權限 600')
p = inst('install', 'gemini'); g = json.load(open(os.path.join(repo, '.gemini', 'settings.json'))); ok(p.returncode == 0 and 'guguboard' in g['mcpServers'], 'mcp install gemini → .gemini/settings.json')
p = inst('install', 'codex'); inst('install', 'codex'); t = open(os.path.join(home, '.codex', 'config.toml')).read(); ok(t.count('[mcp_servers.guguboard]') == 1 and 'mcp-stdio.ps1' in t, 'mcp install codex → config.toml（重複執行不重複）')
p = inst('install', 'claude-desktop'); f = os.path.join(home, '.config', 'Claude', 'claude_desktop_config.json')
if sys.platform == 'darwin': f = os.path.join(home, 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json')
ok(os.path.exists(f) and 'guguboard' in open(f).read(), 'mcp install claude-desktop')
p = inst('uninstall', 'codex'); ok('[mcp_servers.guguboard]' not in open(os.path.join(home, '.codex', 'config.toml')).read(), 'mcp uninstall codex')
# 照 Cursor 設定檔的指令啟動橋接：不給任何環境變數，靠 .ai-pm/project.json＋使用者 token 檔
ent = cur['mcpServers']['guguboard']
async def via_cfg():
    async with stdio_client(StdioServerParameters(command=ent['command'] if ent['command'] != 'pwsh' else PWSH, args=ent['args'], env=env, cwd=os.path.join(repo, '.ai-pm', 'x'))) as (rd, wr):
        async with ClientSession(rd, wr) as sess:
            await flow(sess, 'stdio(設定檔)')
asyncio.run(via_cfg())

# ---- 稽核：每次工具呼叫都有紀錄，且不含 token ----
au = [json.loads(l) for l in open(os.path.join(CFG, 'account-audit.jsonl'), encoding='utf-8') if l.strip()]
mc = [a for a in au if a['action'] == 'mcp.tool']
ok(len(mc) >= 20 and any(a['detail']['tool'] == 'submit_for_tdd' and a['detail']['ok'] for a in mc) and any(a['detail']['error'] == 'E_RULES' for a in mc), f'稽核紀錄 {len(mc)} 筆 mcp.tool（含成功與規則拒絕）')
ok(DEV not in open(os.path.join(CFG, 'account-audit.jsonl'), encoding='utf-8').read(), '稽核紀錄不含 token')
call('/api/admin/integrations', {'mcp': {'enabled': False}})
print('全部通過' if not fails else f'{fails} 項失敗'); sys.exit(1 if fails else 0)
