# Changelog

格式依 [Keep a Changelog](https://keepachangelog.com/zh-TW/1.1.0/)，版本依 [SemVer](https://semver.org/lang/zh-TW/)。

## [0.1.0] - 2026-11-03
### 新增
- 進度看板：board.json 即時看板、甘特圖、燃盡／燃起圖、篩選、歷史、備註、多專案。
- 健康燈號規則 L1–L7（伺服器、前端、AI Hooks、Git Hooks、CI Guard 一致）。
- 五個 AI 開發流程技能，支援 Cursor、Claude Code、Codex、Copilot、Windsurf、Gemini CLI、Cline／Roo Code。
- 套用到專案：預覽、`.bak` 備份、合併 hooks 設定、移除還原。
- Git 分頁（不提供 force push）、AI 提示詞、Agent API、領單與派工器、帳號與群組、GitHub PR 通知、Google 整合（選用）。
- MCP 伺服器（Streamable HTTP `/mcp`＋stdio 橋接，預設關閉）：14 個工具、協作提示詞、per-agent token、`guguboard mcp install <client>`；L1–L7 與角色權限在伺服器端檢查，AI 不能結案或核准佈署，每次呼叫都有稽核紀錄。
- 繁中／英文介面；淺／灰／深／GuGu 主題；GuGuBoard 標誌。
- 安裝：Windows NSIS 安裝檔與 PowerShell zip；macOS tar.gz／.pkg 與 GuGuBoard.app；Linux tar.gz 與 .deb；`get-guguboard.sh` 一行安裝。
- CI（ubuntu／macOS／Windows）與 Release 工作流程（含 SHA256SUMS）。
- 以 Apache-2.0 授權。

[0.1.0]: https://github.com/roy791202/GuGuBoard/releases/tag/v0.1.0
