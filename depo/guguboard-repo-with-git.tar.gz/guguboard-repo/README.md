<p align="center"><img src="assets/gugu-logo.svg" alt="GuGuBoard" width="320"></p>

<p align="center"><b>AI 開發流程看板：讓 AI 代理照規格、BDD／TDD 與燈號規則做事，人負責核准。</b><br>
本機執行、無雲端相依、Windows／macOS／Linux。</p>

<p align="center">
<a href="LICENSE"><img alt="License: Apache-2.0" src="https://img.shields.io/badge/license-Apache--2.0-blue"></a>
<img alt="version" src="https://img.shields.io/badge/version-0.1.0-orange">
</p>

[English](#english) · [繁體中文](#繁體中文)

---

## 繁體中文

<p align="center"><img src="docs/board-theme-gugu-screenshot.png" alt="GuGuBoard 看板（GuGu 主題）" width="860"></p>

### 功能

- **進度看板**：`<repo>/.ai-pm/board.json` 為唯一資料來源，看板即時更新；甘特圖、燃盡／燃起圖、篩選、歷史與備註。
- **健康燈號 L1–L7**：伺服器、前端、AI Hooks、Git Hooks、CI Guard 用同一組規則檢查，AI 不能把沒有證據的工作標成完成。
- **五個 AI 開發流程技能**：預製期 → 實作期 → PR 驗收期，以及上線就緒標準；轉成 Cursor、Claude Code、Codex（AGENTS.md）、Copilot、Windsurf、Gemini CLI、Cline／Roo Code 各自的格式。
- **套用到專案**：先預覽，再寫入；既有檔案先備份 `.bak`，可完整移除還原；預設不自動 commit。
- **強制層**：AI Hooks（Cursor／Claude Code 動作前後檢查）、`.githooks`（pre-commit／commit-msg）、GitHub Actions CI Guard。
- **Git 分頁**：分支圖、比對、merge／rebase／cherry-pick、衝突處理；危險操作需確認，**不提供 force push**。
- **MCP 伺服器**：Claude Code／Desktop、Cursor、Codex、Gemini CLI、Grok Bot 等任何支援 MCP 的 AI 都能直接連上看板（預設關閉）。
- **AI 提示詞與 Agent API**：領單（claim／lease）、派工器；派工 token 不能核准 Done 或佈署。
- **帳號與權限**：admin／high-tier／verifier／dev-agent／viewer；驗證角色不能是開發角色。
- **多專案、GitHub PR 通知、Google 整合（選用）**、繁中／英文介面、淺／灰／深／GuGu 四種主題。

<p align="center">
<img src="docs/board-git-graph-screenshot.png" alt="Git 分頁" width="420">
<img src="docs/board-gantt-screenshot.png" alt="甘特圖" width="420">
</p>

### 快速開始

需要 **git**；macOS／Linux 另需 **PowerShell 7（pwsh）**。安裝程式不會自動使用 sudo。

**Windows**

```powershell
# 方式一：執行 GuGuBoard-Setup.exe（預設裝到 D:\AI_PM；目前未簽章，SmartScreen 請按「其他資訊 → 仍要執行」）
# 方式二：PowerShell zip
Expand-Archive GuGuBoard-PowerShell.zip GuGuBoard; cd GuGuBoard
powershell -ExecutionPolicy Bypass -File .\install.ps1 -InstallPath D:\AI_PM
```

**macOS**

```sh
brew install --cask powershell          # 先裝 pwsh；git：xcode-select --install
tar xzf GuGuBoard-macOS.tar.gz && sh GuGuBoard-macOS/install.sh   # → ~/Applications/GuGuBoard ＋ GuGuBoard.app
# 或安裝 GuGuBoard-<版本>-macOS.pkg（→ /Applications）
```

**Linux**

```sh
sudo snap install powershell --classic  # 或 Microsoft 套件庫的 powershell
tar xzf GuGuBoard-Linux.tar.gz && sh GuGuBoard-Linux/install.sh   # → ~/.local/share/gugu-board ＋ ~/.local/bin/guguboard
# 或：sudo apt install ./guguboard_<版本>_all.deb
```

**一行安裝（macOS／Linux）**：`curl -fsSL https://github.com/roy791202/GuGuBoard/releases/latest/download/get-guguboard.sh | GUGUBOARD_BASE=https://github.com/roy791202/GuGuBoard/releases/latest/download sh`

啟動與套用：

```sh
guguboard start                         # http://localhost:8765/（第一次會引導建立管理者帳號）
guguboard apply ~/code/my-repo -Plan    # 預覽要寫入專案的檔案
guguboard apply ~/code/my-repo -Tools Cursor,Claude,Hooks,GitHooks,CIGuard
```

完整說明見 [docs/guide.html](docs/guide.html)。

### 用 MCP 連接 AI（Claude、Cursor、Codex、Gemini、Grok Bot）

GuGuBoard 內建 MCP（Model Context Protocol）伺服器，AI 工具連上後就能直接領單、更新進度、送交驗證，不用貼專案路徑。

1. 看板「⚙ 設定 → MCP」勾選「啟用 MCP」（預設關閉），選專案與角色後按「建立 token」（token 只顯示一次，可隨時撤銷）。
2. 選你的 AI 工具，複製設定範例；或在專案資料夾執行：

```sh
guguboard mcp install claude-code -Token aipm_xxxxxxxx_…   # 也可以是 claude-desktop、cursor、codex、gemini、http
# Windows：D:\AI_PM\guguboard.cmd mcp install cursor -Token aipm_…
```

| AI 工具 | 連線方式 |
|---|---|
| Claude Code | `claude mcp add --transport http guguboard http://localhost:8765/mcp --header "Authorization: Bearer <token>"` |
| Claude Desktop、Codex | stdio 橋接 `mcp-stdio.ps1`（`guguboard mcp install` 會寫好設定） |
| Cursor、Gemini CLI | 專案內 `.cursor/mcp.json`／`.gemini/settings.json`（不含 token，可以 commit） |
| Grok Bot 等遠端 AI | `https://<外部監看的公開網址>/mcp`＋`Authorization: Bearer <token>`，需在設定勾選「允許外部 MCP 連線」 |

- **工具**：`list_projects`、`get_board_summary`、`list_tickets`（依燈號／狀態篩選）、`get_ticket`、`claim_ticket`、`renew_lease`、`release_ticket`、`update_ticket_progress`、`add_ticket_note`、`answer_verifier_question`、`submit_for_tdd`、`get_rules`、`list_runs`、`get_run_log`；另有協作提示詞（MCP prompt `guguboard_collaborate`）。
- **規則**：每個工具都走伺服器同一套 L1–L7 與角色權限；AI 一律不能移到 Done／Released、設藍燈或核准佈署。被拒絕時回傳規則編號與中文原因（例如 `[L4] 黃燈必須填 lightReason`）。
- **稽核**：每次工具呼叫都記在 `.ai-board/account-audit.jsonl`（`mcp.tool`，不含 token）。
- **token 存放**：`guguboard mcp install` 把 token 存在 `~/.guguboard/mcp.json`（權限 600），不會寫進 repo。

<p align="center"><img src="docs/board-mcp-settings-screenshot.png" alt="MCP 設定" width="560"></p>

### 從原始碼建置

```sh
python3 scripts/build.py            # → dist/：Setup.exe（需要 makensis）、PowerShell zip、macOS／Linux tar.gz、.deb（需要 dpkg-deb）、SHA256SUMS.txt
sh scripts/build_pkg.sh             # macOS 上產生 .pkg（需要 pkgbuild）
```

測試：`pwsh tests/parse-check.ps1`、`sh tests/unix-install.sh dist`、`pwsh tests/windows-install.ps1`、端對端 `eval "$(sh tests/e2e-setup.sh)" && node tests/rules-layers.test.js`（見 [tests/README.md](tests/README.md)）。

### 架構

```
瀏覽器（board.html，無 CDN）
   ⇅ HTTP（localhost，CSRF 標頭＋Origin 檢查，Session Cookie）
serve-board.ps1（PowerShell HttpListener）── serve-ext.ps1（Agent API、派工器、整合）
   ├─ <repo>/.ai-pm/board.json   ← 看板資料（schema：board.schema.json，燈號規則 L1–L7）
   ├─ git CLI                    ← Git 分頁（參數一律驗證並以 -- 分隔）
   ├─ GitHub API（選用）          ← PR 通知；token 只存在伺服器端
   └─ <安裝資料夾>/.ai-board/     ← 帳號、專案登記、稽核紀錄（不進 git）
apply-project.ps1 → 專案 repo：AI 規則／技能、.ai-hooks、.githooks、.github/workflows/ai-dev-guard.yml
```

| 資料夾 | 內容 |
|---|---|
| `src/board` | 看板伺服器、前端、套用到專案、schema |
| `src/hooks` | AI Hooks 與 board 驗證器 |
| `enforce` | Git Hooks、CI Guard |
| `skills` | 五個 AI 開發流程技能（SKILL.md） |
| `templates` | BDD 範本 |
| `installer/windows` | install.ps1／uninstall.ps1、NSIS 產生器 |
| `installer/unix`、`installer/macos`、`installer/linux` | install.sh、啟動器 guguboard、.app、.desktop |
| `scripts` | 建置腳本（從 repo 根目錄執行） |
| `tests` | 安裝冒煙測試、端對端測試 |
| `docs` | 使用指南與截圖 |

### 安全模型

- 伺服器只綁定 `localhost`；所有寫入 API 需要登入 Session、`X-Board-Request` 標頭與相符的 Origin。
- 密碼加鹽雜湊；連續錯誤鎖定；敏感操作（重設密碼、套用到專案）只限本機管理者。
- **GitHub token 只存在伺服器端，絕不送到瀏覽器。**
- Git 操作：**永不 force push（包含 --force-with-lease）、永不 --no-verify**；不刪 main／受保護／目前分支；`reset --hard` 只限明確「捨棄」＋危險確認且只動本機。
- 專案檔案不默默覆蓋（先 `.bak`）；預設不自動 commit。
- macOS／Linux：`.ai-board` 權限 700／600；Windows 依 NTFS ACL。
- 漏洞回報請見 [SECURITY.md](SECURITY.md)。

### 授權

以 [Apache License 2.0](LICENSE) 授權，另見 [NOTICE](NOTICE)。

---

## English

GuGuBoard is a local, dependency-free progress board and rule set that keeps AI coding agents (Cursor, Claude Code, Codex, Copilot, Windsurf, Gemini CLI, Cline) on a spec → BDD/TDD → PR workflow, while humans approve. It runs on Windows, macOS and Linux (PowerShell 7 on macOS/Linux; Windows PowerShell 5.1 or later on Windows). The UI is Traditional Chinese first, with English available.

**Features:** a live board backed by `<repo>/.ai-pm/board.json`; health lights L1–L7 enforced identically by the server, UI, AI hooks, git hooks and CI; five workflow skills converted for seven AI tools; "apply to project" with preview, `.bak` backups and clean removal; a Git tab with no force push; an agent API with claims, leases and a dispatcher; roles and permissions; multi-project support; GitHub PR notifications; four themes.

**MCP:** GuGuBoard includes an MCP server (off by default). Turn it on under ⚙ Settings → MCP, create a per-agent token, and connect Claude Code (`claude mcp add --transport http guguboard http://localhost:8765/mcp --header "Authorization: Bearer <token>"`), Claude Desktop, Cursor, Codex or Gemini CLI. You can also run `guguboard mcp install <client> -Token <token>`. Remote agents such as Grok Bot connect to `https://<public-url>/mcp` once "Allow external MCP connections" is ticked. Every tool call goes through the same L1–L7 and role checks. Agents can never move a ticket to Done or Released, set a blue light, or approve a deployment. Rejections include the rule number, and every call is audited.

**Quick start**
- Windows: run `GuGuBoard-Setup.exe`, or unzip `GuGuBoard-PowerShell.zip` and run `install.ps1`.
- macOS: `brew install --cask powershell`, then `sh GuGuBoard-macOS/install.sh`, or install the `.pkg`.
- Linux: install pwsh, then `sh GuGuBoard-Linux/install.sh`, or `sudo apt install ./guguboard_<ver>_all.deb`.
- Then run `guguboard start` and open http://localhost:8765/.

**Build:** `python3 scripts/build.py` writes everything to `dist/` with `SHA256SUMS.txt`. On macOS, `sh scripts/build_pkg.sh` builds the `.pkg`. Pushing a tag `v*` builds and publishes a draft GitHub Release.

**Security:** the server listens on localhost only and requires a session, a CSRF header and an Origin check. GitHub tokens stay server-side and are never sent to the browser. There is no force push and no `--no-verify`. Project files are never overwritten silently (a `.bak` is kept first). See [SECURITY.md](SECURITY.md).

**License:** [Apache-2.0](LICENSE).

## 聯絡 Contact

維護者：roy791202@gmail.com ・ Issues：https://github.com/roy791202/GuGuBoard/issues ・ 安全問題請見 [SECURITY.md](SECURITY.md)
