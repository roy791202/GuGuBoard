# 安全政策 Security Policy

## 支援版本
| 版本 | 支援 |
|---|---|
| 0.1.x | ✅ |

## 回報漏洞
請**不要**在公開 issue 回報安全問題。請寄信到 **roy791202@gmail.com**（主旨加 `[GuGuBoard security]`），或使用 GitHub 的 **Private vulnerability reporting**（https://github.com/roy791202/GuGuBoard/security/advisories/new）。
Please do not open public issues for security problems. Email roy791202@gmail.com, or use GitHub private vulnerability reporting.

請附上：影響版本、作業系統、重現步驟、影響範圍。我們會在 7 天內回覆，並在修正發佈後公開致謝（如你同意）。

## 範圍
特別重視：本機伺服器的認證與 CSRF、GitHub token 外洩、Git 操作造成資料遺失（force push、hard reset）、套用到專案時覆蓋檔案、路徑穿越、安裝程式權限、MCP 端點（/mcp）的 token 認證與規則繞過。
