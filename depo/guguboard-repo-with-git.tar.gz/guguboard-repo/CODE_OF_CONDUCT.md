# 行為準則 Code of Conduct

本專案採用 [Contributor Covenant 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/)。
This project follows the Contributor Covenant, version 2.1.

我們承諾讓每個人都能在友善、尊重、不受騷擾的環境中參與，不論年齡、體型、身心障礙、族群、性別認同與表達、經驗、教育、社經地位、國籍、外貌、種族、宗教或性傾向。

不被接受的行為包括：騷擾、人身攻擊、歧視性言論、未經同意公開他人私人資訊。

違反準則的情況請透過 GitHub 私訊維護者或 SECURITY.md 所列的私下管道回報；維護者會保密處理，並可採取警告、暫時或永久禁止參與等措施。
